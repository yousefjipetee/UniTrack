const searchInput = document.getElementById("adminCourseSearch");
const courseRows = document.querySelectorAll(".admin-course-row");
const noSearchResults = document.getElementById("noAdminSearchResults");

if (searchInput) {
    searchInput.addEventListener("input", function () {
        const searchTerm = searchInput.value.trim().toLowerCase();
        let visibleRows = 0;

        courseRows.forEach(function (row) {
            const courseCode = row.dataset.courseCode || "";
            const courseName = row.dataset.courseName || "";
            const instructor = row.dataset.instructor || "";

            const matches =
                courseCode.includes(searchTerm) ||
                courseName.includes(searchTerm) ||
                instructor.includes(searchTerm);

            row.style.display = matches ? "" : "none";

            if (matches) {
                visibleRows++;
            }
        });

        if (noSearchResults) {
            noSearchResults.style.display =
                visibleRows === 0 ? "block" : "none";
        }
    });
}

const deleteButtons = document.querySelectorAll(".delete-course-button");

deleteButtons.forEach(function (button) {
    button.addEventListener("click", async function () {
        const courseId = button.dataset.courseId;
        const csrfToken = document
            .querySelector('meta[name="csrf-token"]')
            ?.getAttribute("content");

        if (!csrfToken) {
            alert("Security token is missing. Please refresh the page.");
            return;
        }

        const confirmed = confirm(
            "Are you sure you want to delete this course?"
        );

        if (!confirmed) {
            return;
        }

        button.disabled = true;

        try {
            const response = await fetch("course-delete.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: new URLSearchParams({
                    id: courseId,
                    csrf_token: csrfToken
                })
            });

            if (response.ok) {
                window.location.href = "courses.php?deleted=1";
                return;
            }

            const errorMessage = await response.text();

            alert(
                errorMessage ||
                "Unable to delete the course."
            );

            button.disabled = false;
        } catch (error) {
            console.error(error);

            alert("An unexpected error occurred.");

            button.disabled = false;
        }
    });
});