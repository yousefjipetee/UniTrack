const registerForm = document.getElementById("registerForm");

if (registerForm) {
    registerForm.addEventListener("submit", function (event) {
        let isValid = true;

        const name = document.getElementById("name");
        const email = document.getElementById("email");
        const password = document.getElementById("password");
        const confirmPassword = document.getElementById("confirm_password");

        const nameError = document.getElementById("nameError");
        const emailError = document.getElementById("emailError");
        const passwordError = document.getElementById("passwordError");
        const confirmPasswordError =
            document.getElementById("confirmPasswordError");

        nameError.innerText = "";
        emailError.innerText = "";
        passwordError.innerText = "";
        confirmPasswordError.innerText = "";

        name.classList.remove("input-error");
        email.classList.remove("input-error");
        password.classList.remove("input-error");
        confirmPassword.classList.remove("input-error");

        const nameValue = name.value.trim();
        const emailValue = email.value.trim();
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (nameValue === "") {
            nameError.innerText = "Please enter your full name.";
            name.classList.add("input-error");
            isValid = false;
        } else if (nameValue.length < 3) {
            nameError.innerText =
                "Name must be at least 3 characters.";
            name.classList.add("input-error");
            isValid = false;
        }

        if (emailValue === "") {
            emailError.innerText =
                "Please enter your email address.";
            email.classList.add("input-error");
            isValid = false;
        } else if (!emailPattern.test(emailValue)) {
            emailError.innerText =
                "Please enter a valid email address.";
            email.classList.add("input-error");
            isValid = false;
        }

        if (password.value === "") {
            passwordError.innerText =
                "Please enter a password.";
            password.classList.add("input-error");
            isValid = false;
        } else if (password.value.length < 8) {
            passwordError.innerText =
                "Password must be at least 8 characters.";
            password.classList.add("input-error");
            isValid = false;
        }

        if (confirmPassword.value === "") {
            confirmPasswordError.innerText =
                "Please confirm your password.";
            confirmPassword.classList.add("input-error");
            isValid = false;
        } else if (password.value !== confirmPassword.value) {
            confirmPasswordError.innerText =
                "Passwords do not match.";
            confirmPassword.classList.add("input-error");
            isValid = false;
        }

        if (!isValid) {
            event.preventDefault();
        }
    });
}