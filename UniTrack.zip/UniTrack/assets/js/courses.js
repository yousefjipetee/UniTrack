const courseSearch = document.getElementById("courseSearch");
const courseCards = document.querySelectorAll(".course-card");

function setCookie(name, value, days) {
    const expirationDate = new Date();

    expirationDate.setTime(
        expirationDate.getTime() +
        days * 24 * 60 * 60 * 1000
    );

    document.cookie =
        `${name}=${encodeURIComponent(value)};expires=${expirationDate.toUTCString()};path=/;SameSite=Lax`;
}

function getCookie(name) {
    const cookies = document.cookie.split(";");

    for (const cookie of cookies) {
        const trimmedCookie = cookie.trim();

        if (trimmedCookie.startsWith(`${name}=`)) {
            return decodeURIComponent(
                trimmedCookie.substring(name.length + 1)
            );
        }
    }

    return "";
}

function filterCourses(searchValue) {
    courseCards.forEach(function (card) {
        const courseName =
            (card.dataset.courseName || "").toLowerCase();

        const courseCode =
            (card.dataset.courseCode || "").toLowerCase();

        const instructor =
            (card.dataset.instructor || "").toLowerCase();

        const matches =
            courseName.includes(searchValue) ||
            courseCode.includes(searchValue) ||
            instructor.includes(searchValue);

        card.style.display = matches ? "flex" : "none";
    });
}

if (courseSearch) {
    const savedSearch = getCookie("unitrack_course_search");

    if (savedSearch !== "") {
        courseSearch.value = savedSearch;

        filterCourses(
            savedSearch.trim().toLowerCase()
        );
    }

    courseSearch.addEventListener("input", function () {
        const searchValue =
            courseSearch.value.trim().toLowerCase();

        filterCourses(searchValue);

        setCookie(
            "unitrack_course_search",
            courseSearch.value,
            7
        );
    });
}