const dropButtons = document.querySelectorAll(".drop-course-button");
const securityElement = document.getElementById("myCoursesSecurity");
const csrfToken = securityElement?.dataset.csrfToken || "";

dropButtons.forEach(function (button) {
    button.addEventListener("click", async function () {
        const courseId = button.dataset.courseId;

        if (!confirm("Are you sure you want to drop this course?")) {
            return;
        }

        if (!csrfToken) {
            alert("Security token is missing. Please refresh the page.");
            return;
        }

        button.disabled = true;

        try {
            const response = await fetch("../api/drop-course.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    course_id: courseId,
                    csrf_token: csrfToken
                })
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                alert(
                    data.message ||
                    "Unable to drop the course."
                );

                button.disabled = false;
                return;
            }

            alert(data.message);

            const courseCard = button.closest(".course-card");

            if (courseCard) {
                courseCard.remove();
            }
        } catch (error) {
            console.error(error);

            alert(
                "An unexpected error occurred. Please try again."
            );

            button.disabled = false;
        }
    });
});