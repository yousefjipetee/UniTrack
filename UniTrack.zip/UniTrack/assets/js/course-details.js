const enrollmentMessage = document.getElementById("enrollmentMessage");
const enrollButton = document.querySelector(".enroll-button");
const dropButton = document.querySelector(".drop-button");
const availableSeatsElement = document.getElementById("availableSeats");
const enrolledStudentsElement = document.getElementById("enrolledStudents");
const studentStatusElement = document.getElementById("studentStatus");

function getCsrfToken() {
    return enrollmentMessage?.dataset.csrfToken || "";
}

function showEnrollmentMessage(message, type) {
    if (!enrollmentMessage) {
        return;
    }

    enrollmentMessage.innerText = message;

    enrollmentMessage.classList.remove(
        "message-success",
        "message-error"
    );

    enrollmentMessage.classList.add(
        type === "success"
            ? "message-success"
            : "message-error"
    );
}

function updateCourseStats(enrolledCount, remainingSeats) {
    if (enrolledStudentsElement) {
        enrolledStudentsElement.innerText = enrolledCount;
    }

    if (availableSeatsElement) {
        availableSeatsElement.innerText = remainingSeats;
    }
}

function updateStudentStatus(status) {
    if (!studentStatusElement) {
        return;
    }

    if (status === "active") {
        studentStatusElement.innerText = "Enrolled";
    } else if (status === "dropped") {
        studentStatusElement.innerText = "Dropped";
    } else {
        studentStatusElement.innerText = "Not Enrolled";
    }
}

function updateEnrollmentUI(status, courseId) {
    const statusContainer =
        document.getElementById("enrollmentActions");

    if (!statusContainer) {
        return;
    }

    statusContainer.innerHTML = "";

    if (status === "active") {
        const button = document.createElement("button");

        button.type = "button";
        button.classList.add("btn-danger", "drop-button");
        button.dataset.courseId = courseId;
        button.innerText = "Drop Course";

        statusContainer.appendChild(button);

        button.addEventListener("click", function () {
            dropCourse(button.dataset.courseId);
        });

        return;
    }

    const availableSeats = availableSeatsElement
        ? parseInt(availableSeatsElement.innerText, 10)
        : 0;

    if (availableSeats > 0) {
        const button = document.createElement("button");

        button.type = "button";
        button.classList.add("btn-primary", "enroll-button");
        button.dataset.courseId = courseId;
        button.innerText = "Enroll in Course";

        statusContainer.appendChild(button);

        button.addEventListener("click", function () {
            enrollCourse(button.dataset.courseId);
        });

        return;
    }

    const fullMessage = document.createElement("span");

    fullMessage.classList.add("course-status", "full");
    fullMessage.innerText = "Course Full";

    statusContainer.appendChild(fullMessage);
}

async function enrollCourse(courseId) {
    const csrfToken = getCsrfToken();

    if (!csrfToken) {
        showEnrollmentMessage(
            "Security token is missing.",
            "error"
        );
        return;
    }

    const currentEnrollButton =
        document.querySelector(".enroll-button");

    if (currentEnrollButton) {
        currentEnrollButton.disabled = true;
    }

    try {
        const response = await fetch(
            "../api/enroll-course.php",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    course_id: parseInt(courseId, 10),
                    csrf_token: csrfToken
                })
            }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
            showEnrollmentMessage(
                data.message ||
                "Unable to enroll in this course.",
                "error"
            );

            if (currentEnrollButton) {
                currentEnrollButton.disabled = false;
            }

            return;
        }

        showEnrollmentMessage(
            data.message,
            "success"
        );

        updateCourseStats(
            data.enrolled_count,
            data.remaining_seats
        );

        updateStudentStatus("active");
        updateEnrollmentUI("active", courseId);
    } catch (error) {
        console.error(error);

        showEnrollmentMessage(
            "An unexpected error occurred.",
            "error"
        );

        if (currentEnrollButton) {
            currentEnrollButton.disabled = false;
        }
    }
}

async function dropCourse(courseId) {
    const confirmed = confirm(
        "Are you sure you want to drop this course?"
    );

    if (!confirmed) {
        return;
    }

    const csrfToken = getCsrfToken();

    if (!csrfToken) {
        showEnrollmentMessage(
            "Security token is missing.",
            "error"
        );
        return;
    }

    const currentDropButton =
        document.querySelector(".drop-button");

    if (currentDropButton) {
        currentDropButton.disabled = true;
    }

    try {
        const response = await fetch(
            "../api/drop-course.php",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    course_id: parseInt(courseId, 10),
                    csrf_token: csrfToken
                })
            }
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
            showEnrollmentMessage(
                data.message ||
                "Unable to drop this course.",
                "error"
            );

            if (currentDropButton) {
                currentDropButton.disabled = false;
            }

            return;
        }

        showEnrollmentMessage(
            data.message,
            "success"
        );

        updateCourseStats(
            data.enrolled_count,
            data.remaining_seats
        );

        updateStudentStatus("dropped");
        updateEnrollmentUI("dropped", courseId);
    } catch (error) {
        console.error(error);

        showEnrollmentMessage(
            "An unexpected error occurred.",
            "error"
        );

        if (currentDropButton) {
            currentDropButton.disabled = false;
        }
    }
}

if (enrollButton) {
    enrollButton.addEventListener("click", function () {
        enrollCourse(enrollButton.dataset.courseId);
    });
}

if (dropButton) {
    dropButton.addEventListener("click", function () {
        dropCourse(dropButton.dataset.courseId);
    });
}