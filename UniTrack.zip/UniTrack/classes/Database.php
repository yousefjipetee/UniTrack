<?php

require_once __DIR__ . '/../includes/config.php';

class Database
{
    private mysqli $connection;

    public function __construct()
    {
        $this->connection = new mysqli(
            DB_HOST,
            DB_USER,
            DB_PASS,
            DB_NAME
        );

        if ($this->connection->connect_error) {
            die(
                "Database connection failed: " .
                $this->connection->connect_error
            );
        }

        $this->connection->set_charset("utf8mb4");
    }

    public function getConnection(): mysqli
    {
        return $this->connection;
    }
}