<?php

require_once __DIR__ . '/Database.php';

class Course
{
    private mysqli $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function getAll(): array
    {
        $stmt = $this->db->prepare("
            SELECT
                c.id,
                c.department_id,
                c.instructor_id,
                c.course_code,
                c.course_name,
                c.description,
                c.credits,
                c.capacity,
                c.schedule,
                c.created_at,
                d.name AS department_name,
                i.name AS instructor_name,
                COUNT(
                    CASE
                        WHEN e.status = 'active' THEN e.id
                    END
                ) AS enrolled_count
            FROM courses c
            INNER JOIN departments d
                ON c.department_id = d.id
            INNER JOIN instructors i
                ON c.instructor_id = i.id
            LEFT JOIN enrollments e
                ON c.id = e.course_id
            GROUP BY
                c.id,
                c.department_id,
                c.instructor_id,
                c.course_code,
                c.course_name,
                c.description,
                c.credits,
                c.capacity,
                c.schedule,
                c.created_at,
                d.name,
                i.name
            ORDER BY c.course_code ASC
        ");

        $stmt->execute();

        $result = $stmt->get_result();
        $courses = [];

        while ($row = $result->fetch_assoc()) {
            $courses[] = $row;
        }

        $stmt->close();

        return $courses;
    }

    public function getById(int $courseId): ?array
    {
        $stmt = $this->db->prepare("
            SELECT
                c.id,
                c.department_id,
                c.instructor_id,
                c.course_code,
                c.course_name,
                c.description,
                c.credits,
                c.capacity,
                c.schedule,
                c.created_at,
                d.name AS department_name,
                i.name AS instructor_name
            FROM courses c
            INNER JOIN departments d
                ON c.department_id = d.id
            INNER JOIN instructors i
                ON c.instructor_id = i.id
            WHERE c.id = ?
            LIMIT 1
        ");

        $stmt->bind_param("i", $courseId);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows !== 1) {
            $stmt->close();
            return null;
        }

        $course = $result->fetch_assoc();

        $stmt->close();

        return $course;
    }

    public function create(
        int $departmentId,
        int $instructorId,
        string $courseCode,
        string $courseName,
        string $description,
        int $credits,
        int $capacity,
        ?string $schedule = null
    ): bool {
        $stmt = $this->db->prepare("
            INSERT INTO courses (
                department_id,
                instructor_id,
                course_code,
                course_name,
                description,
                credits,
                capacity,
                schedule
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "iisssiis",
            $departmentId,
            $instructorId,
            $courseCode,
            $courseName,
            $description,
            $credits,
            $capacity,
            $schedule
        );

        $success = $stmt->execute();

        $stmt->close();

        return $success;
    }

    public function update(
        int $courseId,
        int $departmentId,
        int $instructorId,
        string $courseCode,
        string $courseName,
        string $description,
        int $credits,
        int $capacity,
        ?string $schedule = null
    ): bool {
        $stmt = $this->db->prepare("
            UPDATE courses
            SET
                department_id = ?,
                instructor_id = ?,
                course_code = ?,
                course_name = ?,
                description = ?,
                credits = ?,
                capacity = ?,
                schedule = ?
            WHERE id = ?
        ");

        $stmt->bind_param(
            "iisssiisi",
            $departmentId,
            $instructorId,
            $courseCode,
            $courseName,
            $description,
            $credits,
            $capacity,
            $schedule,
            $courseId
        );

        $success = $stmt->execute();

        $stmt->close();

        return $success;
    }

    public function delete(int $courseId): bool
    {
        $stmt = $this->db->prepare("
            DELETE FROM courses
            WHERE id = ?
        ");

        $stmt->bind_param("i", $courseId);

        $success = $stmt->execute();

        $stmt->close();

        return $success;
    }

    public function exists(int $courseId): bool
    {
        $stmt = $this->db->prepare("
            SELECT id
            FROM courses
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->bind_param("i", $courseId);
        $stmt->execute();

        $result = $stmt->get_result();
        $exists = $result->num_rows === 1;

        $stmt->close();

        return $exists;
    }

    public function getActiveEnrollmentCount(int $courseId): int
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) AS total
            FROM enrollments
            WHERE course_id = ?
            AND status = 'active'
        ");

        $stmt->bind_param("i", $courseId);
        $stmt->execute();

        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $stmt->close();

        return (int) $row['total'];
    }

    public function hasAvailableSeat(int $courseId): bool
    {
        $stmt = $this->db->prepare("
            SELECT
                c.capacity,
                COUNT(
                    CASE
                        WHEN e.status = 'active' THEN e.id
                    END
                ) AS enrolled_count
            FROM courses c
            LEFT JOIN enrollments e
                ON c.id = e.course_id
            WHERE c.id = ?
            GROUP BY c.id, c.capacity
        ");

        $stmt->bind_param("i", $courseId);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows !== 1) {
            $stmt->close();
            return false;
        }

        $row = $result->fetch_assoc();

        $stmt->close();

        return (int) $row['enrolled_count']
            < (int) $row['capacity'];
    }
}