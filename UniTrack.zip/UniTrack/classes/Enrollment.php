<?php

require_once __DIR__ . '/Database.php';

class Enrollment
{
    private mysqli $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function exists(int $studentId, int $courseId): bool
    {
        $stmt = $this->db->prepare("
            SELECT id
            FROM enrollments
            WHERE student_id = ?
            AND course_id = ?
            LIMIT 1
        ");

        $stmt->bind_param("ii", $studentId, $courseId);
        $stmt->execute();

        $result = $stmt->get_result();
        $exists = $result->num_rows === 1;

        $stmt->close();

        return $exists;
    }

    public function get(int $studentId, int $courseId): ?array
    {
        $stmt = $this->db->prepare("
            SELECT
                id,
                student_id,
                course_id,
                enrolled_at,
                status
            FROM enrollments
            WHERE student_id = ?
            AND course_id = ?
            LIMIT 1
        ");

        $stmt->bind_param("ii", $studentId, $courseId);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows !== 1) {
            $stmt->close();
            return null;
        }

        $enrollment = $result->fetch_assoc();

        $stmt->close();

        return $enrollment;
    }

    public function enroll(int $studentId, int $courseId): bool
    {
        $existing = $this->get($studentId, $courseId);

        if ($existing !== null) {
            if ($existing['status'] === 'active') {
                return false;
            }

            $stmt = $this->db->prepare("
                UPDATE enrollments
                SET
                    status = 'active',
                    enrolled_at = CURRENT_TIMESTAMP
                WHERE student_id = ?
                AND course_id = ?
            ");

            $stmt->bind_param(
                "ii",
                $studentId,
                $courseId
            );

            $success = $stmt->execute();

            $stmt->close();

            return $success;
        }

        $status = 'active';

        $stmt = $this->db->prepare("
            INSERT INTO enrollments (
                student_id,
                course_id,
                status
            )
            VALUES (?, ?, ?)
        ");

        $stmt->bind_param(
            "iis",
            $studentId,
            $courseId,
            $status
        );

        $success = $stmt->execute();

        $stmt->close();

        return $success;
    }

    public function drop(int $studentId, int $courseId): bool
    {
        $stmt = $this->db->prepare("
            UPDATE enrollments
            SET status = 'dropped'
            WHERE student_id = ?
            AND course_id = ?
            AND status = 'active'
        ");

        $stmt->bind_param("ii", $studentId, $courseId);

        $success = $stmt->execute();

        $stmt->close();

        return $success;
    }

    public function getActiveCourses(int $studentId): array
    {
        $stmt = $this->db->prepare("
            SELECT
                e.id AS enrollment_id,
                e.enrolled_at,
                e.status,
                c.id AS course_id,
                c.course_code,
                c.course_name,
                c.description,
                c.credits,
                c.capacity,
                c.schedule,
                i.name AS instructor_name,
                d.name AS department_name
            FROM enrollments e
            INNER JOIN courses c
                ON e.course_id = c.id
            INNER JOIN instructors i
                ON c.instructor_id = i.id
            INNER JOIN departments d
                ON c.department_id = d.id
            WHERE e.student_id = ?
            AND e.status = 'active'
            ORDER BY c.course_code ASC
        ");

        $stmt->bind_param("i", $studentId);
        $stmt->execute();

        $result = $stmt->get_result();
        $courses = [];

        while ($row = $result->fetch_assoc()) {
            $courses[] = $row;
        }

        $stmt->close();

        return $courses;
    }

    public function getHistory(int $studentId): array
    {
        $stmt = $this->db->prepare("
            SELECT
                e.id,
                e.enrolled_at,
                e.status,
                c.id AS course_id,
                c.course_code,
                c.course_name,
                c.credits,
                i.name AS instructor_name,
                d.name AS department_name
            FROM enrollments e
            INNER JOIN courses c
                ON e.course_id = c.id
            INNER JOIN instructors i
                ON c.instructor_id = i.id
            INNER JOIN departments d
                ON c.department_id = d.id
            WHERE e.student_id = ?
            ORDER BY e.enrolled_at DESC
        ");

        $stmt->bind_param("i", $studentId);
        $stmt->execute();

        $result = $stmt->get_result();
        $history = [];

        while ($row = $result->fetch_assoc()) {
            $history[] = $row;
        }

        $stmt->close();

        return $history;
    }

    public function countActiveCourses(int $studentId): int
    {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) AS total
            FROM enrollments
            WHERE student_id = ?
            AND status = 'active'
        ");

        $stmt->bind_param("i", $studentId);
        $stmt->execute();

        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $stmt->close();

        return (int) $row['total'];
    }

    public function getActiveCredits(int $studentId): int
    {
        $stmt = $this->db->prepare("
            SELECT
                COALESCE(SUM(c.credits), 0) AS total_credits
            FROM enrollments e
            INNER JOIN courses c
                ON e.course_id = c.id
            WHERE e.student_id = ?
            AND e.status = 'active'
        ");

        $stmt->bind_param("i", $studentId);
        $stmt->execute();

        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        $stmt->close();

        return (int) $row['total_credits'];
    }
}