<?php

require_once __DIR__ . '/../includes/config.php';

class Encryption
{
    private const CIPHER = 'aes-256-gcm';

    public static function encrypt(string $plainText): string
    {
        $key = ENCRYPTION_KEY;
        $ivLength = openssl_cipher_iv_length(self::CIPHER);
        $iv = random_bytes($ivLength);
        $tag = '';

        $encrypted = openssl_encrypt(
            $plainText,
            self::CIPHER,
            $key,
            OPENSSL_RAW_DATA,
            $iv,
            $tag,
            '',
            16
        );

        if ($encrypted === false) {
            throw new RuntimeException('Encryption failed.');
        }

        return base64_encode($iv . $tag . $encrypted);
    }

    public static function decrypt(string $encryptedText): string
    {
        $key = ENCRYPTION_KEY;
        $decoded = base64_decode($encryptedText, true);

        if ($decoded === false) {
            throw new RuntimeException('Invalid encrypted data.');
        }

        $ivLength = openssl_cipher_iv_length(self::CIPHER);

        $iv = substr($decoded, 0, $ivLength);
        $tag = substr($decoded, $ivLength, 16);
        $cipherText = substr($decoded, $ivLength + 16);

        $decrypted = openssl_decrypt(
            $cipherText,
            self::CIPHER,
            $key,
            OPENSSL_RAW_DATA,
            $iv,
            $tag
        );

        if ($decrypted === false) {
            throw new RuntimeException('Decryption failed.');
        }

        return $decrypted;
    }
}