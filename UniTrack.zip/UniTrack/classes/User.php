<?php

require_once __DIR__ . '/Database.php';

class User
{
    private mysqli $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function emailExists(string $email): bool
    {
        $stmt = $this->db->prepare(
            "SELECT id
             FROM users
             WHERE email = ?
             LIMIT 1"
        );

        $stmt->bind_param("s", $email);
        $stmt->execute();

        $result = $stmt->get_result();
        $exists = $result->num_rows > 0;

        $stmt->close();

        return $exists;
    }

    public function register(
        string $name,
        string $email,
        string $password
    ): bool {
        $hashedPassword = password_hash(
            $password,
            PASSWORD_DEFAULT
        );

        $role = "student";

        $stmt = $this->db->prepare(
            "INSERT INTO users (
                name,
                email,
                password,
                role
            )
            VALUES (?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "ssss",
            $name,
            $email,
            $hashedPassword,
            $role
        );

        $success = $stmt->execute();

        $stmt->close();

        return $success;
    }

    public function login(
        string $email,
        string $password
    ): ?array {
        $stmt = $this->db->prepare(
            "SELECT
                id,
                name,
                email,
                password,
                role
             FROM users
             WHERE email = ?
             LIMIT 1"
        );

        $stmt->bind_param("s", $email);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows !== 1) {
            $stmt->close();
            return null;
        }

        $user = $result->fetch_assoc();

        $stmt->close();

        if (!password_verify($password, $user['password'])) {
            return null;
        }

        unset($user['password']);

        return $user;
    }
}