<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../classes/Database.php';

requireStudent();

$database = new Database();
$db = $database->getConnection();

$studentId = (int) $_SESSION['user_id'];

$sql = "
    SELECT
        c.id,
        c.course_code,
        c.course_name,
        c.description,
        c.credits,
        c.capacity,
        i.name AS instructor_name,
        d.name AS department_name,
        COUNT(
            CASE
                WHEN e.status = 'active' THEN e.id
            END
        ) AS enrolled_count,
        (
            SELECT e2.status
            FROM enrollments e2
            WHERE e2.student_id = ?
            AND e2.course_id = c.id
            LIMIT 1
        ) AS student_status
    FROM courses c
    INNER JOIN instructors i
        ON c.instructor_id = i.id
    INNER JOIN departments d
        ON c.department_id = d.id
    LEFT JOIN enrollments e
        ON c.id = e.course_id
    GROUP BY
        c.id,
        c.course_code,
        c.course_name,
        c.description,
        c.credits,
        c.capacity,
        i.name,
        d.name
    ORDER BY c.course_code ASC
";

$stmt = $db->prepare($sql);
$stmt->bind_param("i", $studentId);
$stmt->execute();

$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Browse Courses | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >
</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">
            <h2>UniTrack</h2>
            <span>Student Portal</span>
        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a
                href="courses.php"
                class="active"
            >
                Browse Courses
            </a>

            <a href="my-courses.php">
                My Courses
            </a>

            <a href="history.php">
                Academic History
            </a>

            <a href="profile.php">
                Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </nav>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div>
                <h1>Browse Courses</h1>

                <p>
                    Explore available Computer Science courses.
                </p>
            </div>

        </header>

        <section class="course-tools">

            <div class="search-box">

                <label for="courseSearch">
                    Search Courses
                </label>

                <input
                    type="text"
                    id="courseSearch"
                    placeholder="Search by course name, code, or instructor..."
                    autocomplete="off"
                >

            </div>

        </section>

        <section class="courses-section">

            <div
                class="course-grid"
                id="courseGrid"
            >

                <?php if ($result->num_rows === 0): ?>

                    <div class="empty-state">

                        <h3>
                            No courses found
                        </h3>

                        <p>
                            There are currently no courses available.
                        </p>

                    </div>

                <?php else: ?>

                    <?php while ($course = $result->fetch_assoc()): ?>

                        <?php
                        $courseId = (int) $course['id'];
                        $courseCode = htmlspecialchars(
                            $course['course_code']
                        );
                        $courseName = htmlspecialchars(
                            $course['course_name']
                        );
                        $description = htmlspecialchars(
                            $course['description'] ?? ''
                        );
                        $instructorName = htmlspecialchars(
                            $course['instructor_name']
                        );
                        $departmentName = htmlspecialchars(
                            $course['department_name']
                        );
                        $credits = (int) $course['credits'];
                        $capacity = (int) $course['capacity'];
                        $enrolledCount = (int) $course['enrolled_count'];
                        $availableSeats = max(
                            0,
                            $capacity - $enrolledCount
                        );
                        $studentStatus = $course['student_status'];
                        ?>

                        <article
                            class="course-card"
                            data-course-name="<?= strtolower($courseName) ?>"
                            data-course-code="<?= strtolower($courseCode) ?>"
                            data-instructor="<?= strtolower($instructorName) ?>"
                        >

                            <div class="course-card-header">

                                <span class="course-code">
                                    <?= $courseCode ?>
                                </span>

                                <?php if ($studentStatus === 'active'): ?>

                                    <span class="course-status active">
                                        Enrolled
                                    </span>

                                <?php elseif ($studentStatus === 'dropped'): ?>

                                    <span class="course-status dropped">
                                        Dropped
                                    </span>

                                <?php elseif ($availableSeats > 0): ?>

                                    <span class="course-status available">
                                        Available
                                    </span>

                                <?php else: ?>

                                    <span class="course-status full">
                                        Full
                                    </span>

                                <?php endif; ?>

                            </div>

                            <h3>
                                <?= $courseName ?>
                            </h3>

                            <p class="course-description">
                                <?= $description ?>
                            </p>

                            <div class="course-info">

                                <div>
                                    <strong>Instructor</strong>
                                    <span>
                                        <?= $instructorName ?>
                                    </span>
                                </div>

                                <div>
                                    <strong>Department</strong>
                                    <span>
                                        <?= $departmentName ?>
                                    </span>
                                </div>

                                <div>
                                    <strong>Credits</strong>
                                    <span>
                                        <?= $credits ?>
                                    </span>
                                </div>

                                <div>
                                    <strong>Seats</strong>
                                    <span>
                                        <?= $availableSeats ?> / <?= $capacity ?>
                                    </span>
                                </div>

                            </div>

                            <div class="course-actions">

                                <a
                                    href="course-details.php?id=<?= $courseId ?>"
                                    class="btn-primary"
                                >
                                    View Course
                                </a>

                                <?php if ($studentStatus === 'active'): ?>

                                    <span class="course-status active">
                                        Currently Enrolled
                                    </span>

                                <?php elseif ($availableSeats <= 0): ?>

                                    <span class="course-status full">
                                        Course Full
                                    </span>

                                <?php endif; ?>

                            </div>

                        </article>

                    <?php endwhile; ?>

                <?php endif; ?>

            </div>

            <div
                id="noSearchResults"
                class="empty-state"
                style="display: none;"
            >

                <h3>
                    No matching courses
                </h3>

                <p>
                    Try searching with another course name, code, or instructor.
                </p>

            </div>

        </section>

    </main>

</div>

<script src="../assets/js/courses.js"></script>

</body>

</html>

<?php

$stmt->close();

?>