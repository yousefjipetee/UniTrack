<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../classes/Database.php';

requireStudent();

$database = new Database();
$db = $database->getConnection();

$studentId = $_SESSION['user_id'];


// Active courses
$stmt = $db->prepare(
    "SELECT COUNT(*) AS total
     FROM enrollments
     WHERE student_id = ?
     AND status = 'active'"
);

$stmt->bind_param("i", $studentId);
$stmt->execute();

$result = $stmt->get_result();
$activeCourses = (int) $result->fetch_assoc()['total'];

$stmt->close();


// Completed courses
$stmt = $db->prepare(
    "SELECT COUNT(*) AS total
     FROM enrollments
     WHERE student_id = ?
     AND status = 'completed'"
);

$stmt->bind_param("i", $studentId);
$stmt->execute();

$result = $stmt->get_result();
$completedCourses = (int) $result->fetch_assoc()['total'];

$stmt->close();


// Total credits
$stmt = $db->prepare(
    "SELECT COALESCE(SUM(c.credits), 0) AS total
     FROM enrollments e
     INNER JOIN courses c
         ON e.course_id = c.id
     WHERE e.student_id = ?
     AND e.status = 'active'"
);

$stmt->bind_param("i", $studentId);
$stmt->execute();

$result = $stmt->get_result();
$totalCredits = (int) $result->fetch_assoc()['total'];

$stmt->close();


// Available courses
$stmt = $db->prepare(
    "SELECT COUNT(*) AS total
     FROM courses"
);

$stmt->execute();

$result = $stmt->get_result();
$availableCourses = (int) $result->fetch_assoc()['total'];

$stmt->close();


// Current enrolled courses
$stmt = $db->prepare(
    "SELECT
        c.id,
        c.course_code,
        c.course_name,
        c.credits,
        i.name AS instructor_name
     FROM enrollments e
     INNER JOIN courses c
        ON e.course_id = c.id
     INNER JOIN instructors i
        ON c.instructor_id = i.id
     WHERE e.student_id = ?
     AND e.status = 'active'
     ORDER BY e.enrolled_at DESC
     LIMIT 5"
);

$stmt->bind_param("i", $studentId);
$stmt->execute();

$currentCourses = $stmt->get_result();

$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="description"
        content="UniTrack Student Dashboard - Manage courses and academic progress."
    >

    <title>Student Dashboard | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

</head>


<body>

<div class="dashboard-layout">


    <!-- =========================
         SIDEBAR
    ========================== -->

    <aside class="sidebar">

        <div class="sidebar-top">

            <a href="../index.php" class="dashboard-brand">

                <span class="dashboard-brand-icon">
                    U
                </span>

                <span class="dashboard-brand-info">

                    <strong>
                        UniTrack
                    </strong>

                    <small>
                        Computer Science
                    </small>

                </span>

            </a>


            <div class="student-mini-profile">

                <div class="student-avatar">
                    <?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?>
                </div>

                <div>

                    <strong>
                        <?= htmlspecialchars($_SESSION['user_name']) ?>
                    </strong>

                    <span>
                        Student
                    </span>

                </div>

            </div>

        </div>


        <nav class="sidebar-nav" aria-label="Student Navigation">

            <span class="nav-section-title">
                MAIN MENU
            </span>

            <a
                href="dashboard.php"
                class="nav-link active"
            >

                <span class="nav-icon">
                    ⌂
                </span>

                <span>
                    Dashboard
                </span>

            </a>


            <a
                href="courses.php"
                class="nav-link"
            >

                <span class="nav-icon">
                    ◇
                </span>

                <span>
                    Browse Courses
                </span>

            </a>


            <a
                href="my-courses.php"
                class="nav-link"
            >

                <span class="nav-icon">
                    +
                </span>

                <span>
                    My Courses
                </span>

                <?php if ($activeCourses > 0): ?>

                    <span class="nav-count">
                        <?= $activeCourses ?>
                    </span>

                <?php endif; ?>

            </a>


            <a
                href="history.php"
                class="nav-link"
            >

                <span class="nav-icon">
                    ↗
                </span>

                <span>
                    Course History
                </span>

            </a>


            <span class="nav-section-title second">
                ACCOUNT
            </span>


            <a
                href="profile.php"
                class="nav-link"
            >

                <span class="nav-icon">
                    ◉
                </span>

                <span>
                    Profile
                </span>

            </a>

        </nav>


        <div class="sidebar-bottom">

            <a
                href="../logout.php"
                class="logout-link"
            >

                <span>
                    ↪
                </span>

                <span>
                    Sign Out
                </span>

            </a>


            <div class="sidebar-version">

                UniTrack

                <span>
                    Student Portal
                </span>

            </div>

        </div>

    </aside>


    <!-- =========================
         MAIN
    ========================== -->

    <main class="dashboard-main">


        <!-- TOPBAR -->

        <header class="dashboard-topbar">

            <div class="mobile-brand">

                <span>
                    U
                </span>

                <strong>
                    UniTrack
                </strong>

            </div>


            <div class="topbar-actions">

                <a
                    href="courses.php"
                    class="topbar-course-button"
                >

                    <span>
                        +
                    </span>

                    Browse Courses

                </a>


                <a
                    href="profile.php"
                    class="topbar-avatar"
                    title="Profile"
                >
                    <?= strtoupper(substr($_SESSION['user_name'], 0, 1)) ?>
                </a>

            </div>

        </header>


        <!-- PAGE INTRO -->

        <section class="dashboard-intro">

            <div>

                <span class="dashboard-eyebrow">
                    Student Portal
                </span>

                <h1>

                    Welcome back,
                    <span>
                        <?= htmlspecialchars($_SESSION['user_name']) ?>
                    </span>

                </h1>

                <p>
                    Here's an overview of your academic journey
                    and current course activity.
                </p>

            </div>


            <div class="intro-date">

                <span>
                    COMPUTER SCIENCE
                </span>

                <strong>
                    Academic Dashboard
                </strong>

            </div>

        </section>


        <!-- =========================
             STATISTICS
        ========================== -->

        <section class="stats-grid">


            <article class="stat-card stat-primary">

                <div class="stat-card-top">

                    <div class="stat-icon">
                        ◇
                    </div>

                    <span class="stat-arrow">
                        ↗
                    </span>

                </div>

                <div class="stat-info">

                    <span>
                        Active Courses
                    </span>

                    <strong>
                        <?= $activeCourses ?>
                    </strong>

                    <small>
                        Currently enrolled
                    </small>

                </div>

            </article>


            <article class="stat-card">

                <div class="stat-card-top">

                    <div class="stat-icon">
                        C
                    </div>

                    <span class="stat-arrow">
                        →
                    </span>

                </div>

                <div class="stat-info">

                    <span>
                        Total Credits
                    </span>

                    <strong>
                        <?= $totalCredits ?>
                    </strong>

                    <small>
                        Current semester
                    </small>

                </div>

            </article>


            <article class="stat-card">

                <div class="stat-card-top">

                    <div class="stat-icon green">
                        ✓
                    </div>

                    <span class="stat-arrow">
                        →
                    </span>

                </div>

                <div class="stat-info">

                    <span>
                        Completed Courses
                    </span>

                    <strong>
                        <?= $completedCourses ?>
                    </strong>

                    <small>
                        Academic history
                    </small>

                </div>

            </article>


            <article class="stat-card">

                <div class="stat-card-top">

                    <div class="stat-icon purple">
                        +
                    </div>

                    <span class="stat-arrow">
                        ↗
                    </span>

                </div>

                <div class="stat-info">

                    <span>
                        Available Courses
                    </span>

                    <strong>
                        <?= $availableCourses ?>
                    </strong>

                    <small>
                        Explore catalog
                    </small>

                </div>

            </article>

        </section>


        <!-- =========================
             CONTENT GRID
        ========================== -->

        <section class="dashboard-content-grid">


            <!-- CURRENT COURSES -->

            <div class="content-section courses-panel">

                <div class="section-header">

                    <div>

                        <span class="section-eyebrow">
                            Enrollment
                        </span>

                        <h2>
                            My Current Courses
                        </h2>

                        <p>
                            Your currently active enrolled courses.
                        </p>

                    </div>


                    <a
                        href="courses.php"
                        class="section-button"
                    >
                        Browse Courses
                        <span>→</span>
                    </a>

                </div>


                <?php if ($currentCourses->num_rows > 0): ?>

                    <div class="modern-course-list">

                        <?php while ($course = $currentCourses->fetch_assoc()): ?>

                            <a
                                href="course-details.php?id=<?= (int) $course['id'] ?>"
                                class="modern-course-item"
                            >

                                <div class="course-code-box">

                                    <?= htmlspecialchars($course['course_code']) ?>

                                </div>


                                <div class="course-main-info">

                                    <span class="course-small-label">
                                        Computer Science
                                    </span>

                                    <strong>
                                        <?= htmlspecialchars($course['course_name']) ?>
                                    </strong>

                                    <span class="course-instructor">

                                        Instructor:
                                        <?= htmlspecialchars($course['instructor_name']) ?>

                                    </span>

                                </div>


                                <div class="course-credits">

                                    <strong>
                                        <?= (int) $course['credits'] ?>
                                    </strong>

                                    <span>
                                        Credits
                                    </span>

                                </div>


                                <div class="course-item-arrow">
                                    →
                                </div>

                            </a>

                        <?php endwhile; ?>

                    </div>


                    <div class="course-list-footer">

                        <a href="my-courses.php">

                            View all my courses

                            <span>
                                →
                            </span>

                        </a>

                    </div>

                <?php else: ?>


                    <div class="empty-state">

                        <div class="empty-state-icon">
                            +
                        </div>

                        <h3>
                            Start your academic journey
                        </h3>

                        <p>
                            You haven't enrolled in any courses yet.
                            Explore the Computer Science catalog
                            and find your next course.
                        </p>

                        <a
                            href="courses.php"
                            class="empty-state-button"
                        >
                            Explore Courses
                            <span>→</span>
                        </a>

                    </div>

                <?php endif; ?>

            </div>


            <!-- QUICK ACTIONS -->

            <aside class="quick-panel">

                <div class="quick-panel-header">

                    <span class="section-eyebrow">
                        Quick Access
                    </span>

                    <h2>
                        Shortcuts
                    </h2>

                </div>


                <div class="quick-actions">

                    <a
                        href="courses.php"
                        class="quick-action"
                    >

                        <div class="quick-action-icon blue">
                            ◇
                        </div>

                        <div>

                            <strong>
                                Browse Courses
                            </strong>

                            <span>
                                Discover available courses
                            </span>

                        </div>

                        <span class="quick-arrow">
                            →
                        </span>

                    </a>


                    <a
                        href="my-courses.php"
                        class="quick-action"
                    >

                        <div class="quick-action-icon green">
                            +
                        </div>

                        <div>

                            <strong>
                                My Courses
                            </strong>

                            <span>
                                Manage your enrollment
                            </span>

                        </div>

                        <span class="quick-arrow">
                            →
                        </span>

                    </a>


                    <a
                        href="history.php"
                        class="quick-action"
                    >

                        <div class="quick-action-icon purple">
                            ↗
                        </div>

                        <div>

                            <strong>
                                Course History
                            </strong>

                            <span>
                                View your academic record
                            </span>

                        </div>

                        <span class="quick-arrow">
                            →
                        </span>

                    </a>


                    <a
                        href="profile.php"
                        class="quick-action"
                    >

                        <div class="quick-action-icon orange">
                            ◉
                        </div>

                        <div>

                            <strong>
                                My Profile
                            </strong>

                            <span>
                                Update your information
                            </span>

                        </div>

                        <span class="quick-arrow">
                            →
                        </span>

                    </a>

                </div>


                <div class="security-card">

                    <div class="security-icon">
                        ✓
                    </div>

                    <div>

                        <strong>
                            Account Secure
                        </strong>

                        <p>
                            Your account is protected by
                            UniTrack security controls.
                        </p>

                    </div>

                </div>

            </aside>

        </section>


        <!-- FOOTER -->

        <footer class="dashboard-footer">

            <span>
                © <?= date('Y') ?> UniTrack
            </span>

            <span>
                Computer Science Student Portal
            </span>

        </footer>


    </main>

</div>

</body>

</html>