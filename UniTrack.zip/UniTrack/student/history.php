<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../classes/Database.php';

requireStudent();

$database = new Database();
$db = $database->getConnection();

$studentId = (int) $_SESSION['user_id'];

$sql = "
    SELECT
        c.id AS course_id,
        c.course_code,
        c.course_name,
        c.credits,
        i.name AS instructor_name,
        e.status,
        e.enrolled_at
    FROM enrollments e
    INNER JOIN courses c
        ON e.course_id = c.id
    INNER JOIN instructors i
        ON c.instructor_id = i.id
    WHERE e.student_id = ?
    ORDER BY e.enrolled_at DESC
";

$stmt = $db->prepare($sql);
$stmt->bind_param("i", $studentId);
$stmt->execute();

$result = $stmt->get_result();
$historyCount = $result->num_rows;

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Academic History | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >
</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">
            <h2>UniTrack</h2>
            <span>Student Portal</span>
        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="courses.php">
                Browse Courses
            </a>

            <a href="my-courses.php">
                My Courses
            </a>

            <a
                href="history.php"
                class="active"
            >
                Academic History
            </a>

            <a href="profile.php">
                Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </nav>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div>

                <span class="page-eyebrow">
                    ACADEMIC RECORD
                </span>

                <h1>
                    Academic History
                </h1>

                <p>
                    Review your complete course enrollment history.
                </p>

            </div>

            <div class="page-header-stat">

                <span>
                    TOTAL RECORDS
                </span>

                <strong>
                    <?= $historyCount ?>
                </strong>

            </div>

        </header>

        <section class="history-section">

            <?php if ($historyCount === 0): ?>

                <div class="empty-state history-empty-state">

                    <div class="empty-state-icon">
                        ✓
                    </div>

                    <h3>
                        No Academic Records
                    </h3>

                    <p>
                        You have not enrolled in any courses yet.
                        Your academic activity will appear here once
                        you register for a course.
                    </p>

                    <a
                        href="courses.php"
                        class="btn-primary empty-state-button"
                    >
                        Browse Courses
                    </a>

                </div>

            <?php else: ?>

                <div class="history-summary">

                    <div class="history-summary-content">

                        <div class="history-summary-icon">
                            ✓
                        </div>

                        <div>

                            <span>
                                ACADEMIC RECORDS
                            </span>

                            <strong>
                                <?= $historyCount ?>
                                <?= $historyCount !== 1 ? 'course records' : 'course record' ?>
                            </strong>

                        </div>

                    </div>

                    <a
                        href="courses.php"
                        class="summary-link"
                    >
                        Browse Courses
                        <span>→</span>
                    </a>

                </div>

                <div class="history-card">

                    <div class="history-table-header">

                        <div>

                            <h2>
                                Enrollment History
                            </h2>

                            <p>
                                A record of your course activity at UniTrack.
                            </p>

                        </div>

                    </div>

                    <div class="table-container">

                        <table class="data-table">

                            <thead>

                                <tr>

                                    <th>
                                        Course
                                    </th>

                                    <th>
                                        Instructor
                                    </th>

                                    <th>
                                        Credits
                                    </th>

                                    <th>
                                        Status
                                    </th>

                                    <th>
                                        Enrollment Date
                                    </th>

                                    <th>
                                        Action
                                    </th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php while ($course = $result->fetch_assoc()): ?>

                                    <tr>

                                        <td>

                                            <div class="history-course">

                                                <span class="history-course-code">
                                                    <?= htmlspecialchars(
                                                        $course['course_code']
                                                    ) ?>
                                                </span>

                                                <strong>
                                                    <?= htmlspecialchars(
                                                        $course['course_name']
                                                    ) ?>
                                                </strong>

                                            </div>

                                        </td>

                                        <td>

                                            <span class="history-instructor">
                                                <?= htmlspecialchars(
                                                    $course['instructor_name']
                                                ) ?>
                                            </span>

                                        </td>

                                        <td>

                                            <span class="credits-badge">

                                                <?= (int) $course['credits'] ?>

                                                <small>
                                                    CR
                                                </small>

                                            </span>

                                        </td>

                                        <td>

                                            <?php
                                            $status = $course['status'];
                                            ?>

                                            <?php if ($status === 'active'): ?>

                                                <span class="course-status active">
                                                    Active
                                                </span>

                                            <?php elseif ($status === 'dropped'): ?>

                                                <span class="course-status dropped">
                                                    Dropped
                                                </span>

                                            <?php elseif ($status === 'completed'): ?>

                                                <span class="course-status completed">
                                                    Completed
                                                </span>

                                            <?php endif; ?>

                                        </td>

                                        <td>

                                            <span class="history-date">
                                                <?= htmlspecialchars(
                                                    date(
                                                        'M d, Y',
                                                        strtotime(
                                                            $course['enrolled_at']
                                                        )
                                                    )
                                                ) ?>
                                            </span>

                                        </td>

                                        <td>

                                            <a
                                                href="course-details.php?id=<?= (int) $course['course_id'] ?>"
                                                class="history-view-button"
                                            >
                                                View
                                            </a>

                                        </td>

                                    </tr>

                                <?php endwhile; ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            <?php endif; ?>

        </section>

    </main>

</div>

</body>

</html>

<?php

$stmt->close();

?>