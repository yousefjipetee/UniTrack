<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';
require_once __DIR__ . '/../classes/Encryption.php';

requireStudent();

$csrfToken = getCsrfToken();

$database = new Database();
$db = $database->getConnection();

$studentId = (int) $_SESSION['user_id'];

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedCsrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCsrfToken($submittedCsrfToken)) {
        http_response_code(403);
        exit(
            'Invalid security token. Please refresh the page and try again.'
        );
    }

    $phone = trim($_POST['phone'] ?? '');

    if ($phone === '') {
        $message = 'Phone number is required.';
        $messageType = 'error';
    } elseif (!preg_match('/^[0-9+\-\s()]{7,30}$/', $phone)) {
        $message = 'Please enter a valid phone number.';
        $messageType = 'error';
    } else {
        try {
            $encryptedPhone = Encryption::encrypt($phone);

            $stmt = $db->prepare(
                "UPDATE users
                 SET phone = ?
                 WHERE id = ?"
            );

            $stmt->bind_param(
                "si",
                $encryptedPhone,
                $studentId
            );

            if ($stmt->execute()) {
                $message = 'Profile updated successfully.';
                $messageType = 'success';
            } else {
                $message = 'Unable to update your profile.';
                $messageType = 'error';
            }

            $stmt->close();
        } catch (Throwable $error) {
            $message = 'An unexpected error occurred.';
            $messageType = 'error';
        }
    }
}

$stmt = $db->prepare(
    "SELECT
        id,
        name,
        email,
        phone,
        role,
        created_at
     FROM users
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $studentId);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    $stmt->close();
    http_response_code(404);
    exit('User not found.');
}

$user = $result->fetch_assoc();

$stmt->close();

$phone = '';

if (!empty($user['phone'])) {
    try {
        $phone = Encryption::decrypt($user['phone']);
    } catch (Throwable $error) {
        $phone = '';
    }
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Profile | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">
            <h2>UniTrack</h2>
            <span>Student Portal</span>
        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="courses.php">
                Browse Courses
            </a>

            <a href="my-courses.php">
                My Courses
            </a>

            <a href="history.php">
                Academic History
            </a>

            <a
                href="profile.php"
                class="active"
            >
                Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </nav>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div>

                <span class="page-eyebrow">
                    ACCOUNT SETTINGS
                </span>

                <h1>
                    My Profile
                </h1>

                <p>
                    Manage your personal information and account details.
                </p>

            </div>

            <div class="profile-header-avatar">
                <?= strtoupper(
                    substr(
                        htmlspecialchars($user['name']),
                        0,
                        1
                    )
                ) ?>
            </div>

        </header>

        <?php if ($message !== ''): ?>

            <div
                class="profile-message <?= $messageType === 'success'
                    ? 'message-success'
                    : 'message-error' ?>"
            >

                <span class="profile-message-icon">
                    <?= $messageType === 'success' ? '✓' : '!' ?>
                </span>

                <span>
                    <?= htmlspecialchars($message) ?>
                </span>

            </div>

        <?php endif; ?>

        <section class="profile-layout">

            <div class="profile-card">

                <div class="profile-card-header">

                    <div>

                        <span class="profile-card-eyebrow">
                            ACCOUNT
                        </span>

                        <h2>
                            Account Information
                        </h2>

                    </div>

                </div>

                <div class="profile-information">

                    <div class="profile-information-item">

                        <span class="profile-information-label">
                            Full Name
                        </span>

                        <strong>
                            <?= htmlspecialchars($user['name']) ?>
                        </strong>

                    </div>

                    <div class="profile-information-item">

                        <span class="profile-information-label">
                            Email Address
                        </span>

                        <strong>
                            <?= htmlspecialchars($user['email']) ?>
                        </strong>

                    </div>

                    <div class="profile-information-item">

                        <span class="profile-information-label">
                            Account Role
                        </span>

                        <strong class="profile-role">
                            Student
                        </strong>

                    </div>

                    <div class="profile-information-item">

                        <span class="profile-information-label">
                            Account Created
                        </span>

                        <strong>
                            <?= htmlspecialchars(
                                date(
                                    'M d, Y',
                                    strtotime($user['created_at'])
                                )
                            ) ?>
                        </strong>

                    </div>

                </div>

            </div>

            <div class="profile-card">

                <div class="profile-card-header">

                    <div>

                        <span class="profile-card-eyebrow">
                            CONTACT
                        </span>

                        <h2>
                            Contact Information
                        </h2>

                        <p>
                            Update your phone number associated with
                            your UniTrack account.
                        </p>

                    </div>

                </div>

                <div class="profile-security-notice">

                    <div class="profile-security-icon">
                        ✓
                    </div>

                    <div>

                        <strong>
                            Encrypted & Protected
                        </strong>

                        <span>
                            Your phone number is stored using
                            AES-256-GCM encryption.
                        </span>

                    </div>

                </div>

                <form
                    method="POST"
                    action="profile.php"
                    class="profile-form"
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= htmlspecialchars($csrfToken) ?>"
                    >

                    <div class="form-group">

                        <label for="phone">
                            Phone Number
                        </label>

                        <input
                            type="text"
                            id="phone"
                            name="phone"
                            value="<?= htmlspecialchars($phone) ?>"
                            placeholder="+962 7X XXX XXXX"
                            maxlength="30"
                            autocomplete="tel"
                            required
                        >

                        <small>
                            Enter a valid phone number using digits,
                            spaces, +, -, or parentheses.
                        </small>

                    </div>

                    <div class="profile-form-actions">

                        <button
                            type="submit"
                            class="btn-primary profile-save-button"
                        >
                            Save Changes
                        </button>

                    </div>

                </form>

            </div>

        </section>

    </main>

</div>

</body>

</html>