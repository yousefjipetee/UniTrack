<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireStudent();

$csrfToken = getCsrfToken();

$database = new Database();
$db = $database->getConnection();

$studentId = (int) $_SESSION['user_id'];

$sql = "
    SELECT
        e.id AS enrollment_id,
        c.id AS course_id,
        c.course_code,
        c.course_name,
        c.description,
        c.credits,
        c.capacity,
        i.name AS instructor_name,
        e.status,
        e.enrolled_at
    FROM enrollments e
    INNER JOIN courses c
        ON e.course_id = c.id
    INNER JOIN instructors i
        ON c.instructor_id = i.id
    WHERE e.student_id = ?
    AND e.status = 'active'
    ORDER BY c.course_code ASC
";

$stmt = $db->prepare($sql);
$stmt->bind_param("i", $studentId);
$stmt->execute();

$result = $stmt->get_result();
$courseCount = $result->num_rows;

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Courses | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">
            <h2>UniTrack</h2>
            <span>Student Portal</span>
        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="courses.php">
                Browse Courses
            </a>

            <a
                href="my-courses.php"
                class="active"
            >
                My Courses
            </a>

            <a href="history.php">
                Academic History
            </a>

            <a href="profile.php">
                Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </nav>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div>

                <span class="page-eyebrow">
                    ACADEMIC REGISTRATION
                </span>

                <h1>
                    My Courses
                </h1>

                <p>
                    Manage and review the courses you are currently enrolled in.
                </p>

            </div>

            <div class="page-header-stat">

                <span>
                    CURRENT COURSES
                </span>

                <strong>
                    <?= $courseCount ?>
                </strong>

            </div>

        </header>

        <div
            id="myCoursesSecurity"
            data-csrf-token="<?= htmlspecialchars($csrfToken) ?>"
            hidden
        ></div>

        <section class="courses-section">

            <?php if ($courseCount === 0): ?>

                <div class="empty-state">

                    <div class="empty-state-icon">
                        +
                    </div>

                    <h3>
                        No enrolled courses
                    </h3>

                    <p>
                        You are not currently enrolled in any courses.
                        Browse the available Computer Science courses
                        to start building your academic schedule.
                    </p>

                    <a
                        href="courses.php"
                        class="btn-primary empty-state-button"
                    >
                        Browse Courses
                    </a>

                </div>

            <?php else: ?>

                <div class="courses-summary">

                    <div>

                        <span class="summary-label">
                            ENROLLED COURSES
                        </span>

                        <strong>
                            <?= $courseCount ?>
                        </strong>

                    </div>

                    <a
                        href="courses.php"
                        class="summary-link"
                    >
                        Browse More Courses
                        <span>→</span>
                    </a>

                </div>

                <div class="course-grid">

                    <?php while ($course = $result->fetch_assoc()): ?>

                        <article class="course-card my-course-card">

                            <div class="course-card-header">

                                <span class="course-code">
                                    <?= htmlspecialchars($course['course_code']) ?>
                                </span>

                                <span class="course-status active">
                                    Active
                                </span>

                            </div>

                            <h3>
                                <?= htmlspecialchars($course['course_name']) ?>
                            </h3>

                            <p class="course-description">
                                <?= htmlspecialchars(
                                    $course['description'] ?? ''
                                ) ?>
                            </p>

                            <div class="course-info">

                                <div>

                                    <strong>
                                        Instructor
                                    </strong>

                                    <span>
                                        <?= htmlspecialchars(
                                            $course['instructor_name']
                                        ) ?>
                                    </span>

                                </div>

                                <div>

                                    <strong>
                                        Credits
                                    </strong>

                                    <span>
                                        <?= (int) $course['credits'] ?>
                                    </span>

                                </div>

                                <div>

                                    <strong>
                                        Capacity
                                    </strong>

                                    <span>
                                        <?= (int) $course['capacity'] ?> Seats
                                    </span>

                                </div>

                                <div>

                                    <strong>
                                        Enrolled
                                    </strong>

                                    <span>
                                        <?= htmlspecialchars(
                                            date(
                                                'M d, Y',
                                                strtotime($course['enrolled_at'])
                                            )
                                        ) ?>
                                    </span>

                                </div>

                            </div>

                            <div class="course-actions">

                                <a
                                    href="course-details.php?id=<?= (int) $course['course_id'] ?>"
                                    class="btn-primary"
                                >
                                    View Course
                                </a>

                                <button
                                    type="button"
                                    class="btn-danger drop-course-button"
                                    data-course-id="<?= (int) $course['course_id'] ?>"
                                >
                                    Drop Course
                                </button>

                            </div>

                        </article>

                    <?php endwhile; ?>

                </div>

            <?php endif; ?>

        </section>

    </main>

</div>

<script src="../assets/js/my-courses.js"></script>

</body>

</html>

<?php

$stmt->close();

?>