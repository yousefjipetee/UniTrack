<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireStudent();

$database = new Database();
$db = $database->getConnection();

$studentId = $_SESSION['user_id'];

$courseId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$courseId || $courseId <= 0) {
    http_response_code(400);
    exit("Invalid course ID.");
}


/*
|--------------------------------------------------------------------------
| CSRF Token
|--------------------------------------------------------------------------
*/

$csrfToken = getCsrfToken();


/*
|--------------------------------------------------------------------------
| Get Course Details
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        c.id,
        c.course_code,
        c.course_name,
        c.description,
        c.credits,
        c.capacity,
        c.schedule,
        i.name AS instructor_name,
        d.name AS department_name,

        (
            SELECT COUNT(*)
            FROM enrollments e1
            WHERE e1.course_id = c.id
              AND e1.status = 'active'
        ) AS enrolled_count,

        (
            SELECT e2.status
            FROM enrollments e2
            WHERE e2.student_id = ?
              AND e2.course_id = c.id
            LIMIT 1
        ) AS student_status

    FROM courses c

    INNER JOIN instructors i
        ON c.instructor_id = i.id

    INNER JOIN departments d
        ON c.department_id = d.id

    WHERE c.id = ?

    LIMIT 1
";

$stmt = $db->prepare($sql);

$stmt->bind_param(
    "ii",
    $studentId,
    $courseId
);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    http_response_code(404);
    exit("Course not found.");
}

$course = $result->fetch_assoc();

$stmt->close();


/*
|--------------------------------------------------------------------------
| Course Information
|--------------------------------------------------------------------------
*/

$courseCode = htmlspecialchars(
    $course['course_code']
);

$courseName = htmlspecialchars(
    $course['course_name']
);

$description = htmlspecialchars(
    $course['description'] ?? ''
);

$instructorName = htmlspecialchars(
    $course['instructor_name']
);

$departmentName = htmlspecialchars(
    $course['department_name']
);

$credits = (int) $course['credits'];

$capacity = (int) $course['capacity'];

$enrolledCount = (int) $course['enrolled_count'];

$availableSeats = max(
    0,
    $capacity - $enrolledCount
);

$schedule = htmlspecialchars(
    $course['schedule'] ?? 'Schedule not available'
);

$studentStatus = $course['student_status'];

?>

<!DOCTYPE html>

<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?= $courseName ?> | UniTrack
    </title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >

</head>

<body>

<div class="dashboard-layout">


    <!-- Sidebar -->

    <aside class="sidebar">

        <div class="sidebar-brand">

            <h2>
                UniTrack
            </h2>

            <span>
                Student Portal
            </span>

        </div>


        <nav class="sidebar-nav">

            <a href="dashboard.php">
                Dashboard
            </a>

            <a
                href="courses.php"
                class="active"
            >
                Browse Courses
            </a>

            <a href="my-courses.php">
                My Courses
            </a>

            <a href="history.php">
                Academic History
            </a>

            <a href="profile.php">
                Profile
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </nav>

    </aside>


    <!-- Main Content -->

    <main class="main-content">


        <!-- Back Button -->

        <div class="course-back">

            <a href="courses.php">
                ← Back to Courses
            </a>

        </div>


        <!-- Course Header -->

        <section class="course-details-header">

            <div>

                <span class="course-code">
                    <?= $courseCode ?>
                </span>

                <h1>
                    <?= $courseName ?>
                </h1>

                <p>
                    <?= $description ?>
                </p>

            </div>


            <?php if ($studentStatus === 'active'): ?>

                <span class="course-status active">
                    Enrolled
                </span>

            <?php elseif ($availableSeats > 0): ?>

                <span class="course-status available">
                    Available
                </span>

            <?php else: ?>

                <span class="course-status full">
                    Full
                </span>

            <?php endif; ?>

        </section>


        <!-- Course Details Grid -->

        <section class="course-details-grid">


            <!-- Course Information -->

            <div class="details-card">

                <h2>
                    Course Information
                </h2>

                <div class="details-list">


                    <div class="detail-item">

                        <strong>
                            Course Code
                        </strong>

                        <span>
                            <?= $courseCode ?>
                        </span>

                    </div>


                    <div class="detail-item">

                        <strong>
                            Department
                        </strong>

                        <span>
                            <?= $departmentName ?>
                        </span>

                    </div>


                    <div class="detail-item">

                        <strong>
                            Instructor
                        </strong>

                        <span>
                            <?= $instructorName ?>
                        </span>

                    </div>


                    <div class="detail-item">

                        <strong>
                            Credits
                        </strong>

                        <span>
                            <?= $credits ?>
                        </span>

                    </div>


                    <div class="detail-item">

                        <strong>
                            Schedule
                        </strong>

                        <span>
                            <?= $schedule ?>
                        </span>

                    </div>


                </div>

            </div>


            <!-- Enrollment Information -->

            <div class="details-card">

                <h2>
                    Enrollment
                </h2>


                <div class="details-list">


                    <div class="detail-item">

                        <strong>
                            Course Capacity
                        </strong>

                        <span id="courseCapacity">
                            <?= $capacity ?>
                        </span>

                    </div>


                    <div class="detail-item">

                        <strong>
                            Enrolled Students
                        </strong>

                        <span id="enrolledStudents">
                            <?= $enrolledCount ?>
                        </span>

                    </div>


                    <div class="detail-item">

                        <strong>
                            Available Seats
                        </strong>

                        <span id="availableSeats">
                            <?= $availableSeats ?>
                        </span>

                    </div>


                    <div class="detail-item">

                        <strong>
                            Your Status
                        </strong>

                        <span id="studentStatus">

                            <?php if ($studentStatus === 'active'): ?>

                                Enrolled

                            <?php elseif ($studentStatus === 'dropped'): ?>

                                Dropped

                            <?php else: ?>

                                Not Enrolled

                            <?php endif; ?>

                        </span>

                    </div>


                </div>


                <!-- AJAX Message -->

                <div
                    id="enrollmentMessage"
                    data-course-id="<?= $courseId ?>"
                    data-csrf-token="<?= htmlspecialchars($csrfToken) ?>"
                ></div>


                <!-- AJAX Actions -->

                <div
                    id="enrollmentActions"
                    class="course-actions"
                >

                    <?php if ($studentStatus === 'active'): ?>

                        <button
                            type="button"
                            class="btn-danger drop-button"
                            data-course-id="<?= $courseId ?>"
                        >
                            Drop Course
                        </button>


                    <?php elseif ($availableSeats > 0): ?>

                        <button
                            type="button"
                            class="btn-primary enroll-button"
                            data-course-id="<?= $courseId ?>"
                        >
                            Enroll in Course
                        </button>


                    <?php else: ?>

                        <span class="course-status full">
                            Course Full
                        </span>

                    <?php endif; ?>

                </div>


            </div>


        </section>


    </main>

</div>


<script src="../assets/js/course-details.js"></script>

</body>

</html>