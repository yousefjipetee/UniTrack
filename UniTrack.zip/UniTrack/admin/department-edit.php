<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

$database = new Database();
$db = $database->getConnection();

$csrfToken = getCsrfToken();

$departmentId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$departmentId || $departmentId <= 0) {
    header('Location: departments.php?error=invalid_id');
    exit;
}

$stmt = $db->prepare(
    "SELECT id, name, description
     FROM departments
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $departmentId);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {

    $stmt->close();

    header('Location: departments.php?error=not_found');
    exit;
}

$department = $result->fetch_assoc();

$stmt->close();

$name = $department['name'];
$description = $department['description'] ?? '';

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {

        $message = 'Invalid security token. Please refresh the page and try again.';
        $messageType = 'error';

    } else {

        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');

        if ($name === '') {

            $message = 'Department name is required.';
            $messageType = 'error';

        } elseif (mb_strlen($name) > 100) {

            $message = 'Department name must not exceed 100 characters.';
            $messageType = 'error';

        } elseif (mb_strlen($description) > 1000) {

            $message = 'Description must not exceed 1000 characters.';
            $messageType = 'error';

        } else {

            $stmt = $db->prepare(
                "SELECT id
                 FROM departments
                 WHERE name = ?
                   AND id <> ?
                 LIMIT 1"
            );

            $stmt->bind_param(
                "si",
                $name,
                $departmentId
            );

            $stmt->execute();

            $result = $stmt->get_result();
            $departmentExists = $result->num_rows > 0;

            $stmt->close();

            if ($departmentExists) {

                $message = 'A department with this name already exists.';
                $messageType = 'error';

            } else {

                $stmt = $db->prepare(
                    "UPDATE departments
                     SET name = ?,
                         description = ?
                     WHERE id = ?"
                );

                $stmt->bind_param(
                    "ssi",
                    $name,
                    $description,
                    $departmentId
                );

                if ($stmt->execute()) {

                    $stmt->close();

                    header('Location: departments.php?updated=1');
                    exit;
                }

                $message = 'Failed to update the department.';
                $messageType = 'error';

                $stmt->close();
            }
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Edit Department | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">

            <div class="brand-mark">
                U
            </div>

            <div class="brand-text">

                <h2>UniTrack</h2>

                <span>Admin Portal</span>

            </div>

        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">

                <span class="nav-icon">⌂</span>

                <span>Dashboard</span>

            </a>

            <a href="courses.php">

                <span class="nav-icon">▣</span>

                <span>Manage Courses</span>

            </a>

            <a href="students.php">

                <span class="nav-icon">♙</span>

                <span>Students</span>

            </a>

            <a href="instructors.php">

                <span class="nav-icon">♙</span>

                <span>Instructors</span>

            </a>

            <a
                href="departments.php"
                class="active"
            >

                <span class="nav-icon">▤</span>

                <span>Departments</span>

            </a>

        </nav>

        <div class="sidebar-footer">

            <a
                href="../logout.php"
                class="logout-link"
            >

                <span class="nav-icon">↪</span>

                <span>Logout</span>

            </a>

        </div>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div class="page-header-content">

                <div>

                    <span class="page-eyebrow">
                        ACADEMIC MANAGEMENT
                    </span>

                    <h1>Edit Department</h1>

                    <p>
                        Update the academic department information.
                    </p>

                </div>

                <a
                    href="departments.php"
                    class="admin-back-button"
                >
                    ← Back to Departments
                </a>

            </div>

        </header>

        <?php if ($message !== ''): ?>

            <div
                class="<?= $messageType === 'success'
                    ? 'message-success'
                    : 'message-error'
                ?> admin-form-message"
            >

                <span class="form-message-icon">
                    !
                </span>

                <span>
                    <?= htmlspecialchars($message) ?>
                </span>

            </div>

        <?php endif; ?>

        <section class="details-card admin-form-card">

            <div class="admin-form-header">

                <span class="section-eyebrow">
                    DEPARTMENT INFORMATION
                </span>

                <h2>
                    <?= htmlspecialchars($department['name']) ?>
                </h2>

                <p>
                    Update the information below and save your changes.
                </p>

            </div>

            <form
                method="POST"
                action="department-edit.php?id=<?= $departmentId ?>"
                class="admin-course-form"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= htmlspecialchars($csrfToken) ?>"
                >

                <div class="form-section">

                    <div class="form-section-title">

                        <span class="form-section-number">
                            01
                        </span>

                        <div>

                            <h3>Department Identity</h3>

                            <p>
                                Update the department name and description.
                            </p>

                        </div>

                    </div>

                    <div class="form-group">

                        <label for="name">
                            Department Name
                        </label>

                        <input
                            type="text"
                            id="name"
                            name="name"
                            value="<?= htmlspecialchars($name) ?>"
                            maxlength="100"
                            required
                        >

                        <small>
                            Enter a unique academic department name.
                        </small>

                    </div>

                    <div class="form-group">

                        <label for="description">
                            Description
                        </label>

                        <textarea
                            id="description"
                            name="description"
                            rows="6"
                            maxlength="1000"
                            placeholder="Enter department description..."
                        ><?= htmlspecialchars($description) ?></textarea>

                        <small>
                            Provide a short description of the department.
                        </small>

                    </div>

                </div>

                <div class="admin-form-actions">

                    <a
                        href="departments.php"
                        class="admin-cancel-button"
                    >
                        Cancel
                    </a>

                    <button
                        type="submit"
                        class="admin-create-button"
                    >
                        <span>✓</span>
                        Save Changes
                    </button>

                </div>

            </form>

        </section>

    </main>

</div>

</body>

</html>