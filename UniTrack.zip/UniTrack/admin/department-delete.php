<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Invalid request method.');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    exit('Invalid security token. Please refresh the page and try again.');
}

$departmentId = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$departmentId || $departmentId <= 0) {
    header('Location: departments.php?error=invalid_id');
    exit;
}

$database = new Database();
$db = $database->getConnection();

$stmt = $db->prepare(
    "SELECT id
     FROM departments
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $departmentId);
$stmt->execute();

$result = $stmt->get_result();
$departmentExists = $result->num_rows === 1;

$stmt->close();

if (!$departmentExists) {
    header('Location: departments.php?error=not_found');
    exit;
}

$stmt = $db->prepare(
    "SELECT
        (SELECT COUNT(*)
         FROM instructors
         WHERE department_id = ?) +
        (SELECT COUNT(*)
         FROM courses
         WHERE department_id = ?) AS total"
);

$stmt->bind_param(
    "ii",
    $departmentId,
    $departmentId
);

$stmt->execute();

$result = $stmt->get_result();
$totalRelatedData = (int) $result->fetch_assoc()['total'];

$stmt->close();

if ($totalRelatedData > 0) {
    header('Location: departments.php?error=has_data');
    exit;
}

$stmt = $db->prepare(
    "DELETE FROM departments
     WHERE id = ?"
);

$stmt->bind_param("i", $departmentId);

if ($stmt->execute()) {

    $stmt->close();

    header('Location: departments.php?deleted=1');
    exit;
}

$stmt->close();

header('Location: departments.php?error=delete_failed');
exit;