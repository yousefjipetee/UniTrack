<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Invalid request method.');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    exit('Invalid security token. Please refresh the page and try again.');
}

$instructorId = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$instructorId || $instructorId <= 0) {
    http_response_code(400);
    exit('Invalid instructor ID.');
}

$database = new Database();
$db = $database->getConnection();

$stmt = $db->prepare(
    "SELECT id
     FROM instructors
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $instructorId);
$stmt->execute();

$result = $stmt->get_result();
$instructorExists = $result->num_rows === 1;

$stmt->close();

if (!$instructorExists) {
    http_response_code(404);
    exit('Instructor not found.');
}

$stmt = $db->prepare(
    "SELECT COUNT(*) AS total
     FROM courses
     WHERE instructor_id = ?"
);

$stmt->bind_param("i", $instructorId);
$stmt->execute();

$result = $stmt->get_result();
$totalCourses = (int) $result->fetch_assoc()['total'];

$stmt->close();

if ($totalCourses > 0) {
    http_response_code(409);
    exit(
        'This instructor cannot be deleted because they are assigned to one or more courses.'
    );
}

$stmt = $db->prepare(
    "DELETE FROM instructors
     WHERE id = ?"
);

$stmt->bind_param("i", $instructorId);

if (!$stmt->execute()) {
    $stmt->close();
    http_response_code(500);
    exit('Unable to delete instructor.');
}

$stmt->close();

header('Location: instructors.php?deleted=1');
exit;