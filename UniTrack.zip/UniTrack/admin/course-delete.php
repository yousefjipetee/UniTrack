<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Invalid request method.');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    http_response_code(403);
    exit('Invalid security token. Please refresh the page and try again.');
}

$courseId = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$courseId || $courseId <= 0) {
    http_response_code(400);
    exit('Invalid course ID.');
}

$database = new Database();
$db = $database->getConnection();

$stmt = $db->prepare(
    "SELECT id
     FROM courses
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $courseId);
$stmt->execute();

$result = $stmt->get_result();
$courseExists = $result->num_rows === 1;

$stmt->close();

if (!$courseExists) {
    http_response_code(404);
    exit('Course not found.');
}

$stmt = $db->prepare(
    "SELECT COUNT(*) AS total
     FROM enrollments
     WHERE course_id = ?
       AND status = 'active'"
);

$stmt->bind_param("i", $courseId);
$stmt->execute();

$result = $stmt->get_result();
$activeEnrollments = (int) $result->fetch_assoc()['total'];

$stmt->close();

if ($activeEnrollments > 0) {
    http_response_code(409);
    exit(
        'This course cannot be deleted because students are currently enrolled in it.'
    );
}

$stmt = $db->prepare(
    "DELETE FROM courses
     WHERE id = ?"
);

$stmt->bind_param("i", $courseId);

if (!$stmt->execute()) {
    $stmt->close();

    http_response_code(500);
    exit('Unable to delete the course.');
}

$stmt->close();

header('Location: courses.php?deleted=1');
exit;