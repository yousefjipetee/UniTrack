<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

$database = new Database();
$db = $database->getConnection();

$csrfToken = getCsrfToken();

$stmt = $db->prepare(
    "SELECT
        d.id,
        d.name,
        d.description,
        d.created_at,
        COUNT(DISTINCT i.id) AS total_instructors,
        COUNT(DISTINCT c.id) AS total_courses
     FROM departments d
     LEFT JOIN instructors i
        ON i.department_id = d.id
     LEFT JOIN courses c
        ON c.department_id = d.id
     GROUP BY
        d.id,
        d.name,
        d.description,
        d.created_at
     ORDER BY d.name ASC"
);

$stmt->execute();

$result = $stmt->get_result();
$departments = $result->fetch_all(MYSQLI_ASSOC);

$stmt->close();

$departmentCount = count($departments);

$updated = isset($_GET['updated']) && $_GET['updated'] === '1';
$created = isset($_GET['created']) && $_GET['created'] === '1';
$deleted = isset($_GET['deleted']) && $_GET['deleted'] === '1';
$error = $_GET['error'] ?? '';

$successMessage = '';

if ($updated) {
    $successMessage = 'Department updated successfully.';
} elseif ($created) {
    $successMessage = 'Department created successfully.';
} elseif ($deleted) {
    $successMessage = 'Department deleted successfully.';
}

$errorMessage = '';

switch ($error) {
    case 'invalid_id':
        $errorMessage = 'Invalid department ID.';
        break;

    case 'not_found':
        $errorMessage = 'Department not found.';
        break;

    case 'has_data':
        $errorMessage =
            'This department cannot be deleted because it contains instructors or courses.';
        break;

    case 'delete_failed':
        $errorMessage = 'Failed to delete the department.';
        break;
}

?>

<!DOCTYPE html>

<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="csrf-token"
        content="<?= htmlspecialchars($csrfToken) ?>"
    >

    <title>Departments | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">

            <div class="brand-mark">
                U
            </div>

            <div class="brand-text">

                <h2>UniTrack</h2>

                <span>Admin Portal</span>

            </div>

        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">

                <span class="nav-icon">⌂</span>

                <span>Dashboard</span>

            </a>

            <a href="courses.php">

                <span class="nav-icon">▣</span>

                <span>Manage Courses</span>

            </a>

            <a href="students.php">

                <span class="nav-icon">♙</span>

                <span>Students</span>

            </a>

            <a href="instructors.php">

                <span class="nav-icon">♙</span>

                <span>Instructors</span>

            </a>

            <a
                href="departments.php"
                class="active"
            >

                <span class="nav-icon">▤</span>

                <span>Departments</span>

            </a>

        </nav>

        <div class="sidebar-footer">

            <a
                href="../logout.php"
                class="logout-link"
            >

                <span class="nav-icon">↪</span>

                <span>Logout</span>

            </a>

        </div>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div class="page-header-content">

                <div>

                    <span class="page-eyebrow">
                        ACADEMIC MANAGEMENT
                    </span>

                    <h1>Departments</h1>

                    <p>
                        Manage academic departments and their relationships with instructors and courses.
                    </p>

                </div>

                <a
                    href="department-create.php"
                    class="admin-add-button"
                >

                    <span class="add-button-icon">
                        +
                    </span>

                    <span>
                        Add Department
                    </span>

                </a>

            </div>

        </header>

        <?php if ($successMessage !== ''): ?>

            <div class="message-success admin-form-message">

                <span class="form-message-icon">
                    ✓
                </span>

                <span>
                    <?= htmlspecialchars($successMessage) ?>
                </span>

            </div>

        <?php endif; ?>

        <?php if ($errorMessage !== ''): ?>

            <div class="message-error admin-form-message">

                <span class="form-message-icon">
                    !
                </span>

                <span>
                    <?= htmlspecialchars($errorMessage) ?>
                </span>

            </div>

        <?php endif; ?>

        <section class="course-management-toolbar">

            <div class="course-toolbar-content">

                <div>

                    <span class="section-eyebrow">
                        ACADEMIC STRUCTURE
                    </span>

                    <h2>Department Directory</h2>

                    <p>
                        View and manage the academic departments available in UniTrack.
                    </p>

                </div>

                <div class="course-count-badge">

                    <strong>
                        <?= $departmentCount ?>
                    </strong>

                    <span>
                        Departments
                    </span>

                </div>

            </div>

            <div class="admin-course-search">

                <label for="departmentSearch">
                    Search Departments
                </label>

                <div class="admin-search-input-wrapper">

                    <span class="admin-search-icon">
                        ⌕
                    </span>

                    <input
                        type="text"
                        id="departmentSearch"
                        placeholder="Search by department, instructor, or course..."
                        autocomplete="off"
                    >

                </div>

            </div>

        </section>

        <section class="details-card admin-courses-card">

            <div class="admin-table-header">

                <div>

                    <h2>Department Directory</h2>

                    <p>
                        Manage department information and academic relationships.
                    </p>

                </div>

            </div>

            <div class="table-container">

                <table
                    class="data-table admin-courses-table"
                    id="departmentsTable"
                >

                    <thead>

                        <tr>

                            <th>
                                Department
                            </th>

                            <th>
                                Description
                            </th>

                            <th>
                                Instructors
                            </th>

                            <th>
                                Courses
                            </th>

                            <th>
                                Created
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>

                    <tbody id="departmentsBody">

                    <?php if (empty($departments)): ?>

                        <tr>

                            <td
                                colspan="6"
                                class="admin-empty-table"
                            >

                                <div class="admin-empty-content">

                                    <div class="admin-empty-icon">
                                        ▤
                                    </div>

                                    <h3>
                                        No departments available
                                    </h3>

                                    <p>
                                        Create your first academic department to start building the structure.
                                    </p>

                                    <a
                                        href="department-create.php"
                                        class="btn-primary"
                                    >
                                        Add Department
                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php else: ?>

                        <?php foreach ($departments as $department): ?>

                            <?php

                            $departmentId = (int) $department['id'];
                            $departmentName = htmlspecialchars(
                                $department['name']
                            );

                            $description = trim(
                                $department['description'] ?? ''
                            );

                            $instructors = (int) $department['total_instructors'];
                            $courses = (int) $department['total_courses'];

                            $createdDate = date(
                                'Y-m-d',
                                strtotime($department['created_at'])
                            );

                            ?>

                            <tr
                                class="admin-course-row"
                                data-department="<?= strtolower(
                                    htmlspecialchars($department['name'])
                                ) ?>"
                            >

                                <td>

                                    <div class="admin-course-info">

                                        <span class="admin-course-code">
                                            DEPT-<?= $departmentId ?>
                                        </span>

                                        <strong>
                                            <?= $departmentName ?>
                                        </strong>

                                        <span class="admin-course-department">
                                            Academic Department
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <div class="department-description">

                                        <?php if ($description === ''): ?>

                                            <span class="empty-value">
                                                No description
                                            </span>

                                        <?php else: ?>

                                            <?= htmlspecialchars($description) ?>

                                        <?php endif; ?>

                                    </div>

                                </td>

                                <td>

                                    <div class="capacity-cell">

                                        <strong>
                                            <?= $instructors ?>
                                        </strong>

                                        <span>
                                            instructors
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <div class="capacity-cell">

                                        <strong>
                                            <?= $courses ?>
                                        </strong>

                                        <span>
                                            courses
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <span class="history-date">
                                        <?= htmlspecialchars($createdDate) ?>
                                    </span>

                                </td>

                                <td>

                                    <div class="admin-course-actions">

                                        <a
                                            href="department-edit.php?id=<?= $departmentId ?>"
                                            class="admin-edit-button"
                                        >
                                            Edit
                                        </a>

                                        <form
                                            method="POST"
                                            action="department-delete.php"
                                            class="admin-delete-form"
                                            onsubmit="return confirm('Are you sure you want to delete this department?');"
                                        >

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?= $departmentId ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?= htmlspecialchars($csrfToken) ?>"
                                            >

                                            <button
                                                type="submit"
                                                class="admin-delete-button"
                                            >
                                                Delete
                                            </button>

                                        </form>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <div
                id="noDepartmentResults"
                class="admin-search-empty"
                style="display: none;"
            >

                <div class="admin-search-empty-icon">
                    ⌕
                </div>

                <h3>
                    No matching departments
                </h3>

                <p>
                    Try searching with another department name.
                </p>

            </div>

        </section>

    </main>

</div>

<script>

const searchInput = document.getElementById("departmentSearch");
const table = document.getElementById("departmentsTable");
const noResults = document.getElementById("noDepartmentResults");

if (searchInput && table) {

    const rows = table.querySelectorAll(
        "tbody .admin-course-row"
    );

    searchInput.addEventListener(
        "input",
        function () {

            const searchValue = searchInput.value
                .toLowerCase()
                .trim();

            let visibleRows = 0;

            rows.forEach(function (row) {

                const department =
                    row.dataset.department || "";

                const rowText =
                    row.innerText.toLowerCase();

                const matches =
                    department.includes(searchValue) ||
                    rowText.includes(searchValue);

                row.style.display = matches ? "" : "none";

                if (matches) {
                    visibleRows++;
                }

            });

            if (noResults) {
                noResults.style.display =
                    visibleRows === 0 && searchValue !== ""
                        ? "block"
                        : "none";
            }

        }
    );
}

</script>

</body>

</html>