<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

$database = new Database();
$db = $database->getConnection();

$csrfToken = getCsrfToken();

$message = '';
$messageType = '';

$departmentId = null;
$name = '';
$email = '';
$phone = '';

$departments = [];

$stmt = $db->prepare(
    "SELECT id, name
     FROM departments
     ORDER BY name ASC"
);

$stmt->execute();

$result = $stmt->get_result();
$departments = $result->fetch_all(MYSQLI_ASSOC);

$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token. Please refresh the page and try again.');
    }

    $departmentId = filter_input(
        INPUT_POST,
        'department_id',
        FILTER_VALIDATE_INT
    );

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if (!$departmentId) {

        $message = 'Please select a department.';
        $messageType = 'error';

    } elseif ($name === '') {

        $message = 'Instructor name is required.';
        $messageType = 'error';

    } elseif (mb_strlen($name) < 3) {

        $message = 'Instructor name must be at least 3 characters.';
        $messageType = 'error';

    } elseif (
        $email !== '' &&
        !filter_var($email, FILTER_VALIDATE_EMAIL)
    ) {

        $message = 'Please enter a valid email address.';
        $messageType = 'error';

    } elseif (
        $phone !== '' &&
        !preg_match('/^[0-9+\-\s()]{7,30}$/', $phone)
    ) {

        $message = 'Please enter a valid phone number.';
        $messageType = 'error';

    } else {

        $checkDepartment = $db->prepare(
            "SELECT id
             FROM departments
             WHERE id = ?
             LIMIT 1"
        );

        $checkDepartment->bind_param(
            "i",
            $departmentId
        );

        $checkDepartment->execute();

        $departmentResult = $checkDepartment->get_result();

        if ($departmentResult->num_rows !== 1) {

            $message = 'Selected department does not exist.';
            $messageType = 'error';

        } else {

            $check = $db->prepare(
                "SELECT id
                 FROM instructors
                 WHERE name = ?
                   AND department_id = ?
                 LIMIT 1"
            );

            $check->bind_param(
                "si",
                $name,
                $departmentId
            );

            $check->execute();

            $result = $check->get_result();

            if ($result->num_rows > 0) {

                $message =
                    'This instructor already exists in this department.';

                $messageType = 'error';

            } else {

                $stmt = $db->prepare(
                    "INSERT INTO instructors
                    (
                        department_id,
                        name,
                        email,
                        phone
                    )
                    VALUES (?, ?, ?, ?)"
                );

                $stmt->bind_param(
                    "isss",
                    $departmentId,
                    $name,
                    $email,
                    $phone
                );

                if ($stmt->execute()) {

                    $message = 'Instructor created successfully.';
                    $messageType = 'success';

                    $departmentId = null;
                    $name = '';
                    $email = '';
                    $phone = '';

                } else {

                    $message = 'Unable to create instructor.';
                    $messageType = 'error';
                }

                $stmt->close();
            }

            $check->close();
        }

        $checkDepartment->close();
    }
}

?>

<!DOCTYPE html>

<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="csrf-token"
        content="<?= htmlspecialchars($csrfToken) ?>"
    >

    <title>Add Instructor | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">

            <div class="brand-mark">
                U
            </div>

            <div class="brand-text">

                <h2>UniTrack</h2>

                <span>Admin Portal</span>

            </div>

        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">

                <span class="nav-icon">⌂</span>

                <span>Dashboard</span>

            </a>

            <a href="courses.php">

                <span class="nav-icon">▣</span>

                <span>Manage Courses</span>

            </a>

            <a href="students.php">

                <span class="nav-icon">♙</span>

                <span>Students</span>

            </a>

            <a
                href="instructors.php"
                class="active"
            >

                <span class="nav-icon">♙</span>

                <span>Instructors</span>

            </a>

            <a href="departments.php">

                <span class="nav-icon">▤</span>

                <span>Departments</span>

            </a>

        </nav>

        <div class="sidebar-footer">

            <a
                href="../logout.php"
                class="logout-link"
            >

                <span class="nav-icon">↪</span>

                <span>Logout</span>

            </a>

        </div>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div class="page-header-content">

                <div>

                    <span class="page-eyebrow">
                        ACADEMIC MANAGEMENT
                    </span>

                    <h1>Add Instructor</h1>

                    <p>
                        Create a new instructor profile and assign it to an academic department.
                    </p>

                </div>

                <a
                    href="instructors.php"
                    class="admin-add-button"
                >

                    <span class="add-button-icon">
                        ←
                    </span>

                    <span>
                        Back to Instructors
                    </span>

                </a>

            </div>

        </header>

        <?php if ($message !== ''): ?>

            <div
                class="<?= $messageType === 'success'
                    ? 'message-success'
                    : 'message-error'
                ?> admin-form-message"
            >

                <span class="form-message-icon">

                    <?= $messageType === 'success' ? '✓' : '!' ?>

                </span>

                <span>
                    <?= htmlspecialchars($message) ?>
                </span>

            </div>

        <?php endif; ?>

        <section class="details-card admin-form-card">

            <div class="admin-form-header">

                <div>

                    <span class="section-eyebrow">
                        INSTRUCTOR PROFILE
                    </span>

                    <h2>Instructor Information</h2>

                    <p>
                        Enter the instructor details below. Department and name are required.
                    </p>

                </div>

            </div>

            <form
                method="POST"
                action="instructor-create.php"
                id="instructorCreateForm"
                class="admin-form"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= htmlspecialchars($csrfToken) ?>"
                >

                <div class="form-grid">

                    <div class="form-group">

                        <label for="department_id">
                            Department
                        </label>

                        <select
                            id="department_id"
                            name="department_id"
                            required
                        >

                            <option value="">
                                Select Department
                            </option>

                            <?php foreach ($departments as $department): ?>

                                <option
                                    value="<?= (int) $department['id'] ?>"
                                    <?= (
                                        isset($departmentId) &&
                                        (int) $departmentId ===
                                        (int) $department['id']
                                    ) ? 'selected' : '' ?>
                                >

                                    <?= htmlspecialchars(
                                        $department['name']
                                    ) ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <div class="form-group">

                        <label for="name">
                            Instructor Name
                        </label>

                        <input
                            type="text"
                            id="name"
                            name="name"
                            value="<?= htmlspecialchars($name) ?>"
                            minlength="3"
                            maxlength="100"
                            placeholder="Enter instructor name"
                            autocomplete="name"
                            required
                        >

                    </div>

                    <div class="form-group">

                        <label for="email">
                            Email
                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            value="<?= htmlspecialchars($email) ?>"
                            maxlength="150"
                            placeholder="Optional"
                            autocomplete="email"
                        >

                    </div>

                    <div class="form-group">

                        <label for="phone">
                            Phone
                        </label>

                        <input
                            type="text"
                            id="phone"
                            name="phone"
                            value="<?= htmlspecialchars($phone) ?>"
                            maxlength="30"
                            placeholder="Optional"
                            autocomplete="tel"
                        >

                    </div>

                </div>

                <div class="admin-form-footer">

                    <a
                        href="instructors.php"
                        class="btn-secondary"
                    >
                        Cancel
                    </a>

                    <button
                        type="submit"
                        class="btn-primary"
                    >
                        Create Instructor
                    </button>

                </div>

            </form>

        </section>

    </main>

</div>

</body>

</html>