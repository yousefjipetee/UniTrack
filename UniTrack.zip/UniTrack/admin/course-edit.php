<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

$csrfToken = getCsrfToken();

$courseId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$courseId || $courseId <= 0) {
    http_response_code(400);
    exit('Invalid course ID.');
}

$database = new Database();
$db = $database->getConnection();

$message = '';
$messageType = '';

$departments = [];
$instructors = [];

$stmt = $db->prepare(
    "SELECT id, name
     FROM departments
     ORDER BY name ASC"
);

$stmt->execute();

$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $departments[] = $row;
}

$stmt->close();

$stmt = $db->prepare(
    "SELECT id, name, department_id
     FROM instructors
     ORDER BY name ASC"
);

$stmt->execute();

$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $instructors[] = $row;
}

$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {

        $message = 'Invalid security token. Please refresh the page and try again.';
        $messageType = 'error';

    } else {

        $departmentId = filter_input(
            INPUT_POST,
            'department_id',
            FILTER_VALIDATE_INT
        );

        $instructorId = filter_input(
            INPUT_POST,
            'instructor_id',
            FILTER_VALIDATE_INT
        );

        $courseCode = trim($_POST['course_code'] ?? '');
        $courseName = trim($_POST['course_name'] ?? '');
        $description = trim($_POST['description'] ?? '');

        $credits = filter_input(
            INPUT_POST,
            'credits',
            FILTER_VALIDATE_INT
        );

        $capacity = filter_input(
            INPUT_POST,
            'capacity',
            FILTER_VALIDATE_INT
        );

        $schedule = trim($_POST['schedule'] ?? '');

        if (!$departmentId) {

            $message = 'Please select a department.';
            $messageType = 'error';

        } elseif (!$instructorId) {

            $message = 'Please select an instructor.';
            $messageType = 'error';

        } elseif (
            $courseCode === '' ||
            !preg_match('/^[A-Za-z0-9-]{2,20}$/', $courseCode)
        ) {

            $message = 'Course code must contain 2-20 letters, numbers, or hyphens.';
            $messageType = 'error';

        } elseif ($courseName === '') {

            $message = 'Course name is required.';
            $messageType = 'error';

        } elseif (mb_strlen($courseName) < 2) {

            $message = 'Course name is too short.';
            $messageType = 'error';

        } elseif (!$credits || $credits < 1 || $credits > 10) {

            $message = 'Credits must be between 1 and 10.';
            $messageType = 'error';

        } elseif (!$capacity || $capacity < 1) {

            $message = 'Capacity must be greater than zero.';
            $messageType = 'error';

        } else {

            $stmt = $db->prepare(
                "SELECT id
                 FROM courses
                 WHERE course_code = ?
                   AND id <> ?
                 LIMIT 1"
            );

            $stmt->bind_param(
                "si",
                $courseCode,
                $courseId
            );

            $stmt->execute();

            $result = $stmt->get_result();
            $courseCodeExists = $result->num_rows > 0;

            $stmt->close();

            if ($courseCodeExists) {

                $message = 'This course code is already used by another course.';
                $messageType = 'error';

            } else {

                $stmt = $db->prepare(
                    "SELECT id
                     FROM instructors
                     WHERE id = ?
                       AND department_id = ?
                     LIMIT 1"
                );

                $stmt->bind_param(
                    "ii",
                    $instructorId,
                    $departmentId
                );

                $stmt->execute();

                $result = $stmt->get_result();
                $validInstructor = $result->num_rows === 1;

                $stmt->close();

                if (!$validInstructor) {

                    $message =
                        'The selected instructor does not belong to the selected department.';

                    $messageType = 'error';

                } else {

                    $stmt = $db->prepare(
                        "UPDATE courses
                         SET
                            department_id = ?,
                            instructor_id = ?,
                            course_code = ?,
                            course_name = ?,
                            description = ?,
                            credits = ?,
                            capacity = ?,
                            schedule = ?
                         WHERE id = ?"
                    );

                    $stmt->bind_param(
                        "iisssiisi",
                        $departmentId,
                        $instructorId,
                        $courseCode,
                        $courseName,
                        $description,
                        $credits,
                        $capacity,
                        $schedule,
                        $courseId
                    );

                    if ($stmt->execute()) {

                        $message = 'Course updated successfully.';
                        $messageType = 'success';

                    } else {

                        $message = 'Unable to update the course.';
                        $messageType = 'error';
                    }

                    $stmt->close();
                }
            }
        }
    }
}

$stmt = $db->prepare(
    "SELECT
        id,
        department_id,
        instructor_id,
        course_code,
        course_name,
        description,
        credits,
        capacity,
        schedule
     FROM courses
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $courseId);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {

    $stmt->close();

    http_response_code(404);
    exit('Course not found.');
}

$course = $result->fetch_assoc();

$stmt->close();

?>

<!DOCTYPE html>

<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Edit Course | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">

            <div class="brand-mark">
                U
            </div>

            <div class="brand-text">

                <h2>UniTrack</h2>

                <span>Admin Portal</span>

            </div>

        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">

                <span class="nav-icon">⌂</span>

                <span>Dashboard</span>

            </a>

            <a
                href="courses.php"
                class="active"
            >

                <span class="nav-icon">▣</span>

                <span>Manage Courses</span>

            </a>

            <a href="students.php">

                <span class="nav-icon">♙</span>

                <span>Students</span>

            </a>

            <a href="instructors.php">

                <span class="nav-icon">♙</span>

                <span>Instructors</span>

            </a>

            <a href="departments.php">

                <span class="nav-icon">▤</span>

                <span>Departments</span>

            </a>

        </nav>

        <div class="sidebar-footer">

            <a
                href="../logout.php"
                class="logout-link"
            >

                <span class="nav-icon">↪</span>

                <span>Logout</span>

            </a>

        </div>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div class="page-header-content">

                <div>

                    <span class="page-eyebrow">
                        ACADEMIC MANAGEMENT
                    </span>

                    <h1>Edit Course</h1>

                    <p>
                        Update the academic information and settings for this course.
                    </p>

                </div>

                <a
                    href="courses.php"
                    class="admin-back-button"
                >
                    ← Back to Courses
                </a>

            </div>

        </header>

        <?php if ($message !== ''): ?>

            <div
                class="<?= $messageType === 'success'
                    ? 'message-success'
                    : 'message-error'
                ?> admin-form-message"
            >

                <span class="form-message-icon">
                    <?= $messageType === 'success' ? '✓' : '!' ?>
                </span>

                <span>
                    <?= htmlspecialchars($message) ?>
                </span>

            </div>

        <?php endif; ?>

        <section class="details-card admin-form-card">

            <div class="admin-form-header">

                <span class="section-eyebrow">
                    COURSE INFORMATION
                </span>

                <h2>
                    <?= htmlspecialchars($course['course_code']) ?>
                    ·
                    <?= htmlspecialchars($course['course_name']) ?>
                </h2>

                <p>
                    Update the information below and save your changes.
                </p>

            </div>

            <form
                method="POST"
                action="course-edit.php?id=<?= $courseId ?>"
                id="courseEditForm"
                class="admin-course-form"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= htmlspecialchars($csrfToken) ?>"
                >

                <div class="form-section">

                    <div class="form-section-title">

                        <span class="form-section-number">
                            01
                        </span>

                        <div>

                            <h3>Academic Structure</h3>

                            <p>
                                Select the department and instructor.
                            </p>

                        </div>

                    </div>

                    <div class="form-grid">

                        <div class="form-group">

                            <label for="department_id">
                                Department
                            </label>

                            <select
                                id="department_id"
                                name="department_id"
                                required
                            >

                                <?php foreach ($departments as $department): ?>

                                    <option
                                        value="<?= (int) $department['id'] ?>"
                                        <?= (int) $course['department_id'] ===
                                            (int) $department['id']
                                            ? 'selected'
                                            : ''
                                        ?>
                                    >

                                        <?= htmlspecialchars(
                                            $department['name']
                                        ) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                            <small>
                                Choose the academic department for this course.
                            </small>

                        </div>

                        <div class="form-group">

                            <label for="instructor_id">
                                Instructor
                            </label>

                            <select
                                id="instructor_id"
                                name="instructor_id"
                                required
                            >

                                <?php foreach ($instructors as $instructor): ?>

                                    <option
                                        value="<?= (int) $instructor['id'] ?>"
                                        data-department-id="<?= (int) $instructor['department_id'] ?>"
                                        <?= (int) $course['instructor_id'] ===
                                            (int) $instructor['id']
                                            ? 'selected'
                                            : ''
                                        ?>
                                    >

                                        <?= htmlspecialchars(
                                            $instructor['name']
                                        ) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                            <small>
                                Only instructors from the selected department can be assigned.
                            </small>

                        </div>

                    </div>

                </div>

                <div class="form-section">

                    <div class="form-section-title">

                        <span class="form-section-number">
                            02
                        </span>

                        <div>

                            <h3>Course Identity</h3>

                            <p>
                                Update the course code, name, and description.
                            </p>

                        </div>

                    </div>

                    <div class="form-grid">

                        <div class="form-group">

                            <label for="course_code">
                                Course Code
                            </label>

                            <input
                                type="text"
                                id="course_code"
                                name="course_code"
                                value="<?= htmlspecialchars(
                                    $course['course_code']
                                ) ?>"
                                maxlength="20"
                                required
                            >

                            <small>
                                2-20 letters, numbers, or hyphens.
                            </small>

                        </div>

                        <div class="form-group">

                            <label for="course_name">
                                Course Name
                            </label>

                            <input
                                type="text"
                                id="course_name"
                                name="course_name"
                                value="<?= htmlspecialchars(
                                    $course['course_name']
                                ) ?>"
                                maxlength="150"
                                required
                            >

                            <small>
                                Enter the name displayed to students.
                            </small>

                        </div>

                    </div>

                    <div class="form-group">

                        <label for="description">
                            Description
                        </label>

                        <textarea
                            id="description"
                            name="description"
                            rows="5"
                            placeholder="Enter course description"
                        ><?= htmlspecialchars(
                            $course['description'] ?? ''
                        ) ?></textarea>

                        <small>
                            Provide a short description of the course.
                        </small>

                    </div>

                </div>

                <div class="form-section">

                    <div class="form-section-title">

                        <span class="form-section-number">
                            03
                        </span>

                        <div>

                            <h3>Course Settings</h3>

                            <p>
                                Configure credits, capacity, and schedule.
                            </p>

                        </div>

                    </div>

                    <div class="form-grid form-grid-three">

                        <div class="form-group">

                            <label for="credits">
                                Credits
                            </label>

                            <input
                                type="number"
                                id="credits"
                                name="credits"
                                value="<?= (int) $course['credits'] ?>"
                                min="1"
                                max="10"
                                required
                            >

                        </div>

                        <div class="form-group">

                            <label for="capacity">
                                Capacity
                            </label>

                            <input
                                type="number"
                                id="capacity"
                                name="capacity"
                                value="<?= (int) $course['capacity'] ?>"
                                min="1"
                                required
                            >

                        </div>

                        <div class="form-group">

                            <label for="schedule">
                                Schedule
                            </label>

                            <input
                                type="text"
                                id="schedule"
                                name="schedule"
                                value="<?= htmlspecialchars(
                                    $course['schedule'] ?? ''
                                ) ?>"
                                placeholder="Sunday - 10:00 AM"
                                maxlength="100"
                            >

                        </div>

                    </div>

                </div>

                <div class="admin-form-actions">

                    <a
                        href="courses.php"
                        class="admin-cancel-button"
                    >
                        Cancel
                    </a>

                    <button
                        type="submit"
                        class="admin-create-button"
                    >
                        <span>✓</span>
                        Save Changes
                    </button>

                </div>

            </form>

        </section>

    </main>

</div>

<script>

const departmentSelect = document.getElementById("department_id");
const instructorSelect = document.getElementById("instructor_id");

function filterInstructors() {

    const departmentId = departmentSelect.value;

    instructorSelect.querySelectorAll("option").forEach(function (option) {

        const matches =
            option.dataset.departmentId === departmentId;

        option.hidden = !matches;

        if (!matches && option.selected) {
            option.selected = false;
            instructorSelect.value = "";
        }

    });
}

departmentSelect.addEventListener(
    "change",
    filterInstructors
);

filterInstructors();

</script>

</body>

</html>