<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

$csrfToken = getCsrfToken();

$database = new Database();
$db = $database->getConnection();

$stmt = $db->prepare(
    "SELECT
        c.id,
        c.course_code,
        c.course_name,
        c.description,
        c.credits,
        c.capacity,
        c.schedule,
        i.name AS instructor_name,
        d.name AS department_name,
        (
            SELECT COUNT(*)
            FROM enrollments e
            WHERE e.course_id = c.id
              AND e.status = 'active'
        ) AS enrolled_count
     FROM courses c
     INNER JOIN instructors i
        ON c.instructor_id = i.id
     INNER JOIN departments d
        ON c.department_id = d.id
     ORDER BY c.course_code ASC"
);

$stmt->execute();

$result = $stmt->get_result();

$courseCount = $result->num_rows;

?>

<!DOCTYPE html>

<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="csrf-token"
        content="<?= htmlspecialchars($csrfToken) ?>"
    >

    <title>Manage Courses | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">

            <div class="brand-mark">
                U
            </div>

            <div class="brand-text">

                <h2>UniTrack</h2>

                <span>Admin Portal</span>

            </div>

        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">

                <span class="nav-icon">⌂</span>

                <span>Dashboard</span>

            </a>

            <a
                href="courses.php"
                class="active"
            >

                <span class="nav-icon">▣</span>

                <span>Manage Courses</span>

            </a>

            <a href="students.php">

                <span class="nav-icon">♙</span>

                <span>Students</span>

            </a>

            <a href="instructors.php">

                <span class="nav-icon">♙</span>

                <span>Instructors</span>

            </a>

            <a href="departments.php">

                <span class="nav-icon">▤</span>

                <span>Departments</span>

            </a>

        </nav>

        <div class="sidebar-footer">

            <a
                href="../logout.php"
                class="logout-link"
            >

                <span class="nav-icon">↪</span>

                <span>Logout</span>

            </a>

        </div>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div class="page-header-content">

                <div>

                    <span class="page-eyebrow">
                        ACADEMIC MANAGEMENT
                    </span>

                    <h1>Manage Courses</h1>

                    <p>
                        Create, edit, search, and manage Computer Science courses.
                    </p>

                </div>

                <a
                    href="course-create.php"
                    class="admin-add-button"
                >

                    <span class="add-button-icon">
                        +
                    </span>

                    <span>
                        Add Course
                    </span>

                </a>

            </div>

        </header>

        <section class="course-management-toolbar">

            <div class="course-toolbar-content">

                <div>

                    <span class="section-eyebrow">
                        COURSE CATALOG
                    </span>

                    <h2>All Courses</h2>

                    <p>
                        Search and manage courses currently available in UniTrack.
                    </p>

                </div>

                <div class="course-count-badge">

                    <strong>
                        <?= $courseCount ?>
                    </strong>

                    <span>
                        Courses
                    </span>

                </div>

            </div>

            <div class="admin-course-search">

                <label for="adminCourseSearch">
                    Search Courses
                </label>

                <div class="admin-search-input-wrapper">

                    <span class="admin-search-icon">
                        ⌕
                    </span>

                    <input
                        type="text"
                        id="adminCourseSearch"
                        placeholder="Search by course code, name, or instructor..."
                        autocomplete="off"
                    >

                </div>

            </div>

        </section>

        <section class="details-card admin-courses-card">

            <div class="admin-table-header">

                <div>

                    <h2>Course Directory</h2>

                    <p>
                        Manage course information and enrollment capacity.
                    </p>

                </div>

            </div>

            <div class="table-container">

                <table
                    class="data-table admin-courses-table"
                    id="adminCoursesTable"
                >

                    <thead>

                        <tr>

                            <th>Course</th>

                            <th>Instructor</th>

                            <th>Credits</th>

                            <th>Capacity</th>

                            <th>Enrollment</th>

                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody id="adminCoursesBody">

                    <?php if ($courseCount === 0): ?>

                        <tr>

                            <td
                                colspan="6"
                                class="admin-empty-table"
                            >

                                <div class="admin-empty-content">

                                    <div class="admin-empty-icon">
                                        ▣
                                    </div>

                                    <h3>
                                        No courses available
                                    </h3>

                                    <p>
                                        Create your first course to start building the catalog.
                                    </p>

                                    <a
                                        href="course-create.php"
                                        class="btn-primary"
                                    >
                                        Add Course
                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php else: ?>

                        <?php while ($course = $result->fetch_assoc()): ?>

                            <?php

                            $courseId = (int) $course['id'];
                            $courseCode = htmlspecialchars($course['course_code']);
                            $courseName = htmlspecialchars($course['course_name']);
                            $instructorName = htmlspecialchars($course['instructor_name']);
                            $departmentName = htmlspecialchars($course['department_name']);

                            $credits = (int) $course['credits'];
                            $capacity = (int) $course['capacity'];
                            $enrolled = (int) $course['enrolled_count'];

                            $remaining = max(
                                0,
                                $capacity - $enrolled
                            );

                            $enrollmentPercentage = $capacity > 0
                                ? min(
                                    100,
                                    ($enrolled / $capacity) * 100
                                )
                                : 0;

                            ?>

                            <tr
                                class="admin-course-row"
                                data-course-code="<?= strtolower($courseCode) ?>"
                                data-course-name="<?= strtolower($courseName) ?>"
                                data-instructor="<?= strtolower($instructorName) ?>"
                            >

                                <td>

                                    <div class="admin-course-info">

                                        <span class="admin-course-code">
                                            <?= $courseCode ?>
                                        </span>

                                        <strong>
                                            <?= $courseName ?>
                                        </strong>

                                        <span class="admin-course-department">
                                            <?= $departmentName ?>
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <div class="admin-instructor-cell">

                                        <span class="instructor-avatar">
                                            <?= htmlspecialchars(
                                                strtoupper(
                                                    mb_substr(
                                                        $course['instructor_name'],
                                                        0,
                                                        1
                                                    )
                                                )
                                            ) ?>
                                        </span>

                                        <span>
                                            <?= $instructorName ?>
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <span class="credits-badge">
                                        <?= $credits ?> Credits
                                    </span>

                                </td>

                                <td>

                                    <div class="capacity-cell">

                                        <strong>
                                            <?= $capacity ?>
                                        </strong>

                                        <span>
                                            seats
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <div class="enrollment-cell">

                                        <div class="enrollment-numbers">

                                            <strong>
                                                <?= $enrolled ?>
                                            </strong>

                                            <span>
                                                / <?= $capacity ?>
                                            </span>

                                        </div>

                                        <div class="enrollment-progress">

                                            <span
                                                style="width: <?= $enrollmentPercentage ?>%;"
                                            ></span>

                                        </div>

                                        <small>
                                            <?= $remaining ?> seats remaining
                                        </small>

                                    </div>

                                </td>

                                <td>

                                    <div class="admin-course-actions">

                                        <a
                                            href="course-edit.php?id=<?= $courseId ?>"
                                            class="admin-edit-button"
                                        >
                                            Edit
                                        </a>

                                        <button
                                            type="button"
                                            class="admin-delete-button delete-course-button"
                                            data-course-id="<?= $courseId ?>"
                                        >
                                            Delete
                                        </button>

                                    </div>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <div
                id="noAdminSearchResults"
                class="admin-search-empty"
                style="display: none;"
            >

                <div class="admin-search-empty-icon">
                    ⌕
                </div>

                <h3>
                    No matching courses
                </h3>

                <p>
                    Try searching with another course code, name, or instructor.
                </p>

            </div>

        </section>

    </main>

</div>

<script src="../assets/js/admin-courses.js"></script>

</body>

</html>

<?php

$stmt->close();

?>