<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

$database = new Database();
$db = $database->getConnection();

$csrfToken = getCsrfToken();

$students = [];

$stmt = $db->prepare(
    "SELECT
        u.id,
        u.name,
        u.email,
        u.created_at,
        COUNT(
            CASE
                WHEN e.status = 'active' THEN e.id
            END
        ) AS active_courses,
        COALESCE(
            SUM(
                CASE
                    WHEN e.status = 'active' THEN c.credits
                    ELSE 0
                END
            ),
            0
        ) AS active_credits
     FROM users u
     LEFT JOIN enrollments e
        ON u.id = e.student_id
     LEFT JOIN courses c
        ON e.course_id = c.id
     WHERE u.role = 'student'
     GROUP BY
        u.id,
        u.name,
        u.email,
        u.created_at
     ORDER BY u.id DESC"
);

$stmt->execute();

$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

$stmt->close();

$message = '';

if (isset($_GET['updated'])) {
    $message = 'Student information updated successfully.';
}

if (isset($_GET['deleted'])) {
    $message = 'Student deleted successfully.';
}

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="csrf-token"
        content="<?= htmlspecialchars($csrfToken) ?>"
    >

    <title>Students | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">

            <div class="brand-mark">
                U
            </div>

            <div class="brand-text">

                <h2>
                    UniTrack
                </h2>

                <span>
                    Admin Portal
                </span>

            </div>

        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">
                <span class="nav-icon">⌂</span>
                <span>Dashboard</span>
            </a>

            <a href="courses.php">
                <span class="nav-icon">▣</span>
                <span>Manage Courses</span>
            </a>

            <a
                href="students.php"
                class="active"
            >
                <span class="nav-icon">♙</span>
                <span>Students</span>
            </a>

            <a href="instructors.php">
                <span class="nav-icon">♙</span>
                <span>Instructors</span>
            </a>

            <a href="departments.php">
                <span class="nav-icon">▤</span>
                <span>Departments</span>
            </a>

        </nav>

        <div class="sidebar-footer">

            <a
                href="../logout.php"
                class="logout-link"
            >
                <span class="nav-icon">↪</span>
                <span>Logout</span>
            </a>

        </div>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div class="page-header-content">

                <div>

                    <span class="page-eyebrow">
                        ADMINISTRATION
                    </span>

                    <h1>
                        Manage Students
                    </h1>

                    <p>
                        View and manage registered Computer Science students.
                    </p>

                </div>

            </div>

        </header>

        <?php if ($message !== ''): ?>

            <div class="message-success">
                <?= htmlspecialchars($message) ?>
            </div>

        <?php endif; ?>

        <section class="course-tools">

            <div class="search-box">

                <label for="studentSearch">
                    Search Students
                </label>

                <input
                    type="text"
                    id="studentSearch"
                    placeholder="Search by name or email..."
                    autocomplete="off"
                >

            </div>

        </section>

        <section class="details-card">

            <div class="section-heading">

                <div>

                    <span class="section-eyebrow">
                        STUDENT MANAGEMENT
                    </span>

                    <h2>
                        Registered Students
                    </h2>

                    <p>
                        Manage student accounts and enrollment information.
                    </p>

                </div>

            </div>

            <div class="table-wrapper">

                <table class="data-table">

                    <thead>

                        <tr>

                            <th>
                                Student
                            </th>

                            <th>
                                Email
                            </th>

                            <th>
                                Active Courses
                            </th>

                            <th>
                                Credits
                            </th>

                            <th>
                                Registered
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>

                    <tbody id="studentTableBody">

                        <?php if (!empty($students)): ?>

                            <?php foreach ($students as $student): ?>

                                <tr
                                    class="student-row"
                                    data-name="<?= htmlspecialchars(
                                        strtolower($student['name'])
                                    ) ?>"
                                    data-email="<?= htmlspecialchars(
                                        strtolower($student['email'])
                                    ) ?>"
                                >

                                    <td>

                                        <strong>
                                            <?= htmlspecialchars(
                                                $student['name']
                                            ) ?>
                                        </strong>

                                    </td>

                                    <td>
                                        <?= htmlspecialchars(
                                            $student['email']
                                        ) ?>
                                    </td>

                                    <td>
                                        <?= (int) $student['active_courses'] ?>
                                    </td>

                                    <td>
                                        <?= (int) $student['active_credits'] ?>
                                    </td>

                                    <td>

                                        <?= htmlspecialchars(
                                            date(
                                                'M d, Y',
                                                strtotime(
                                                    $student['created_at']
                                                )
                                            )
                                        ) ?>

                                    </td>

                                    <td>

                                        <div class="action-buttons">

                                            <a
                                                href="student-edit.php?id=<?= (int) $student['id'] ?>"
                                                class="btn-primary"
                                            >
                                                Edit
                                            </a>

                                            <form
                                                method="POST"
                                                action="student-delete.php"
                                                class="student-delete-form"
                                            >

                                                <input
                                                    type="hidden"
                                                    name="id"
                                                    value="<?= (int) $student['id'] ?>"
                                                >

                                                <input
                                                    type="hidden"
                                                    name="csrf_token"
                                                    value="<?= htmlspecialchars(
                                                        $csrfToken
                                                    ) ?>"
                                                >

                                                <button
                                                    type="submit"
                                                    class="btn-danger"
                                                >
                                                    Delete
                                                </button>

                                            </form>

                                        </div>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>

                                <td
                                    colspan="6"
                                    class="empty-state"
                                >
                                    No registered students found.
                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <p
                id="noStudentResults"
                class="empty-state"
                hidden
            >
                No students match your search.
            </p>

        </section>

    </main>

</div>

<script src="../assets/js/admin-students.js"></script>

</body>

</html>