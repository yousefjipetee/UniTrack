<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

$database = new Database();
$db = $database->getConnection();

$stmt = $db->prepare(
    "SELECT COUNT(*)
     FROM users
     WHERE role = 'student'"
);

$stmt->execute();
$stmt->bind_result($totalStudents);
$stmt->fetch();
$stmt->close();

$stmt = $db->prepare(
    "SELECT COUNT(*)
     FROM courses"
);

$stmt->execute();
$stmt->bind_result($totalCourses);
$stmt->fetch();
$stmt->close();

$stmt = $db->prepare(
    "SELECT COUNT(*)
     FROM instructors"
);

$stmt->execute();
$stmt->bind_result($totalInstructors);
$stmt->fetch();
$stmt->close();

$stmt = $db->prepare(
    "SELECT COUNT(*)
     FROM enrollments
     WHERE status = 'active'"
);

$stmt->execute();
$stmt->bind_result($totalEnrollments);
$stmt->fetch();
$stmt->close();

?>

<!DOCTYPE html>

<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Admin Dashboard | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">

            <div class="brand-mark">
                U
            </div>

            <div class="brand-text">

                <h2>UniTrack</h2>

                <span>Admin Portal</span>

            </div>

        </div>

        <nav class="sidebar-nav">

            <a
                href="dashboard.php"
                class="active"
            >

                <span class="nav-icon">⌂</span>

                <span>Dashboard</span>

            </a>

            <a href="courses.php">

                <span class="nav-icon">▣</span>

                <span>Manage Courses</span>

            </a>

            <a href="students.php">

                <span class="nav-icon">♙</span>

                <span>Students</span>

            </a>

            <a href="instructors.php">

                <span class="nav-icon">♙</span>

                <span>Instructors</span>

            </a>

            <a href="departments.php">

                <span class="nav-icon">▤</span>

                <span>Departments</span>

            </a>

        </nav>

        <div class="sidebar-footer">

            <a
                href="../logout.php"
                class="logout-link"
            >

                <span class="nav-icon">↪</span>

                <span>Logout</span>

            </a>

        </div>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div class="page-header-content">

                <div>

                    <span class="page-eyebrow">
                        ADMINISTRATION
                    </span>

                    <h1>Admin Dashboard</h1>

                    <p>
                        Monitor and manage the UniTrack university course management system.
                    </p>

                </div>

                <div class="admin-header-badge">

                    <span class="admin-avatar">
                        A
                    </span>

                    <div>

                        <strong>
                            Administrator
                        </strong>

                        <span>
                            System Management
                        </span>

                    </div>

                </div>

            </div>

        </header>

        <section class="stats-grid">

            <article class="stat-card">

                <div class="stat-icon">
                    ♙
                </div>

                <div class="stat-card-content">

                    <span class="stat-label">
                        Total Students
                    </span>

                    <strong class="stat-value">
                        <?= (int) $totalStudents ?>
                    </strong>

                    <span class="stat-description">
                        Registered students
                    </span>

                </div>

            </article>

            <article class="stat-card">

                <div class="stat-icon">
                    ▣
                </div>

                <div class="stat-card-content">

                    <span class="stat-label">
                        Total Courses
                    </span>

                    <strong class="stat-value">
                        <?= (int) $totalCourses ?>
                    </strong>

                    <span class="stat-description">
                        Available courses
                    </span>

                </div>

            </article>

            <article class="stat-card">

                <div class="stat-icon">
                    ♙
                </div>

                <div class="stat-card-content">

                    <span class="stat-label">
                        Instructors
                    </span>

                    <strong class="stat-value">
                        <?= (int) $totalInstructors ?>
                    </strong>

                    <span class="stat-description">
                        Academic instructors
                    </span>

                </div>

            </article>

            <article class="stat-card">

                <div class="stat-icon">
                    ✓
                </div>

                <div class="stat-card-content">

                    <span class="stat-label">
                        Active Enrollments
                    </span>

                    <strong class="stat-value">
                        <?= (int) $totalEnrollments ?>
                    </strong>

                    <span class="stat-description">
                        Current enrollments
                    </span>

                </div>

            </article>

        </section>

        <section class="details-card admin-management-card">

            <div class="section-heading">

                <div>

                    <span class="section-eyebrow">
                        MANAGEMENT
                    </span>

                    <h2>Quick Actions</h2>

                    <p>
                        Access the main administrative areas of UniTrack.
                    </p>

                </div>

            </div>

            <div class="admin-action-grid">

                <a
                    href="courses.php"
                    class="admin-action-card"
                >

                    <div class="admin-action-icon">
                        ▣
                    </div>

                    <div class="admin-action-content">

                        <h3>
                            Manage Courses
                        </h3>

                        <p>
                            Create, edit, search and manage university courses.
                        </p>

                    </div>

                    <span class="admin-action-arrow">
                        →
                    </span>

                </a>

                <a
                    href="students.php"
                    class="admin-action-card"
                >

                    <div class="admin-action-icon">
                        ♙
                    </div>

                    <div class="admin-action-content">

                        <h3>
                            Manage Students
                        </h3>

                        <p>
                            View registered students and their academic enrollment information.
                        </p>

                    </div>

                    <span class="admin-action-arrow">
                        →
                    </span>

                </a>

                <a
                    href="instructors.php"
                    class="admin-action-card"
                >

                    <div class="admin-action-icon">
                        ♙
                    </div>

                    <div class="admin-action-content">

                        <h3>
                            Manage Instructors
                        </h3>

                        <p>
                            Manage instructors and their academic information.
                        </p>

                    </div>

                    <span class="admin-action-arrow">
                        →
                    </span>

                </a>

                <a
                    href="departments.php"
                    class="admin-action-card"
                >

                    <div class="admin-action-icon">
                        ▤
                    </div>

                    <div class="admin-action-content">

                        <h3>
                            Manage Departments
                        </h3>

                        <p>
                            Manage academic departments and their relationships.
                        </p>

                    </div>

                    <span class="admin-action-arrow">
                        →
                    </span>

                </a>

            </div>

        </section>

        <section class="details-card admin-overview-card">

            <div class="section-heading">

                <div>

                    <span class="section-eyebrow">
                        SYSTEM OVERVIEW
                    </span>

                    <h2>UniTrack Administration</h2>

                    <p>
                        Use the administration portal to maintain the university's academic course data.
                    </p>

                </div>

            </div>

            <div class="admin-overview-grid">

                <div class="overview-item">

                    <strong>
                        <?= (int) $totalCourses ?>
                    </strong>

                    <span>
                        Courses
                    </span>

                </div>

                <div class="overview-item">

                    <strong>
                        <?= (int) $totalInstructors ?>
                    </strong>

                    <span>
                        Instructors
                    </span>

                </div>

                <div class="overview-item">

                    <strong>
                        <?= (int) $totalStudents ?>
                    </strong>

                    <span>
                        Students
                    </span>

                </div>

                <div class="overview-item">

                    <strong>
                        <?= (int) $totalEnrollments ?>
                    </strong>

                    <span>
                        Active Enrollments
                    </span>

                </div>

            </div>

        </section>

    </main>

</div>

</body>

</html>