<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Database.php';

requireAdmin();

$database = new Database();
$db = $database->getConnection();

$csrfToken = getCsrfToken();

$stmt = $db->prepare(
    "SELECT
        i.id,
        i.name,
        i.email,
        i.phone,
        d.name AS department_name,
        COUNT(c.id) AS total_courses
     FROM instructors i
     INNER JOIN departments d
        ON i.department_id = d.id
     LEFT JOIN courses c
        ON c.instructor_id = i.id
     GROUP BY
        i.id,
        i.name,
        i.email,
        i.phone,
        d.name
     ORDER BY i.name ASC"
);

$stmt->execute();

$result = $stmt->get_result();
$instructors = $result->fetch_all(MYSQLI_ASSOC);

$stmt->close();

$instructorCount = count($instructors);

$deleted = isset($_GET['deleted']) && $_GET['deleted'] === '1';
$error = $_GET['error'] ?? '';

$successMessage = $deleted
    ? 'Instructor deleted successfully.'
    : '';

$errorMessage = '';

switch ($error) {
    case 'has_courses':
        $errorMessage =
            'This instructor cannot be deleted because they are assigned to one or more courses.';
        break;

    case 'not_found':
        $errorMessage = 'Instructor not found.';
        break;

    case 'invalid_id':
        $errorMessage = 'Invalid instructor ID.';
        break;

    case 'delete_failed':
        $errorMessage = 'Failed to delete the instructor.';
        break;
}

?>

<!DOCTYPE html>

<html lang="en" dir="ltr">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="csrf-token"
        content="<?= htmlspecialchars($csrfToken) ?>"
    >

    <title>Instructors | UniTrack</title>

    <link
        rel="stylesheet"
        href="../assets/css/dashboard.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/courses.css"
    >

</head>

<body>

<div class="dashboard-layout">

    <aside class="sidebar">

        <div class="sidebar-brand">

            <div class="brand-mark">
                U
            </div>

            <div class="brand-text">

                <h2>UniTrack</h2>

                <span>Admin Portal</span>

            </div>

        </div>

        <nav class="sidebar-nav">

            <a href="dashboard.php">

                <span class="nav-icon">⌂</span>

                <span>Dashboard</span>

            </a>

            <a href="courses.php">

                <span class="nav-icon">▣</span>

                <span>Manage Courses</span>

            </a>

            <a href="students.php">

                <span class="nav-icon">♙</span>

                <span>Students</span>

            </a>

            <a
                href="instructors.php"
                class="active"
            >

                <span class="nav-icon">♙</span>

                <span>Instructors</span>

            </a>

            <a href="departments.php">

                <span class="nav-icon">▤</span>

                <span>Departments</span>

            </a>

        </nav>

        <div class="sidebar-footer">

            <a
                href="../logout.php"
                class="logout-link"
            >

                <span class="nav-icon">↪</span>

                <span>Logout</span>

            </a>

        </div>

    </aside>

    <main class="main-content">

        <header class="page-header">

            <div class="page-header-content">

                <div>

                    <span class="page-eyebrow">
                        ACADEMIC MANAGEMENT
                    </span>

                    <h1>Instructors</h1>

                    <p>
                        Manage Computer Science instructors and their course assignments.
                    </p>

                </div>

                <a
                    href="instructor-create.php"
                    class="admin-add-button"
                >

                    <span class="add-button-icon">
                        +
                    </span>

                    <span>
                        Add Instructor
                    </span>

                </a>

            </div>

        </header>

        <?php if ($successMessage !== ''): ?>

            <div class="message-success admin-form-message">

                <span class="form-message-icon">
                    ✓
                </span>

                <span>
                    <?= htmlspecialchars($successMessage) ?>
                </span>

            </div>

        <?php endif; ?>

        <?php if ($errorMessage !== ''): ?>

            <div class="message-error admin-form-message">

                <span class="form-message-icon">
                    !
                </span>

                <span>
                    <?= htmlspecialchars($errorMessage) ?>
                </span>

            </div>

        <?php endif; ?>

        <section class="course-management-toolbar">

            <div class="course-toolbar-content">

                <div>

                    <span class="section-eyebrow">
                        FACULTY DIRECTORY
                    </span>

                    <h2>Instructor Directory</h2>

                    <p>
                        View instructor profiles, departments, and assigned courses.
                    </p>

                </div>

                <div class="course-count-badge">

                    <strong>
                        <?= $instructorCount ?>
                    </strong>

                    <span>
                        Instructors
                    </span>

                </div>

            </div>

            <div class="admin-course-search">

                <label for="instructorSearch">
                    Search Instructors
                </label>

                <div class="admin-search-input-wrapper">

                    <span class="admin-search-icon">
                        ⌕
                    </span>

                    <input
                        type="text"
                        id="instructorSearch"
                        placeholder="Search by instructor, department, email, or phone..."
                        autocomplete="off"
                    >

                </div>

            </div>

        </section>

        <section class="details-card admin-courses-card">

            <div class="admin-table-header">

                <div>

                    <h2>Instructor Directory</h2>

                    <p>
                        Manage instructor information and course assignments.
                    </p>

                </div>

            </div>

            <div class="table-container">

                <table
                    class="data-table admin-courses-table"
                    id="instructorsTable"
                >

                    <thead>

                        <tr>

                            <th>
                                Instructor
                            </th>

                            <th>
                                Department
                            </th>

                            <th>
                                Email
                            </th>

                            <th>
                                Phone
                            </th>

                            <th>
                                Courses
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php if (empty($instructors)): ?>

                        <tr>

                            <td
                                colspan="6"
                                class="admin-empty-table"
                            >

                                <div class="admin-empty-content">

                                    <div class="admin-empty-icon">
                                        ♙
                                    </div>

                                    <h3>
                                        No instructors available
                                    </h3>

                                    <p>
                                        Add an instructor to start managing faculty assignments.
                                    </p>

                                    <a
                                        href="instructor-create.php"
                                        class="btn-primary"
                                    >
                                        Add Instructor
                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php else: ?>

                        <?php foreach ($instructors as $instructor): ?>

                            <tr class="admin-course-row">

                                <td>

                                    <div class="admin-course-info">

                                        <span class="admin-course-code">
                                            INS-<?= (int) $instructor['id'] ?>
                                        </span>

                                        <strong>
                                            <?= htmlspecialchars(
                                                $instructor['name']
                                            ) ?>
                                        </strong>

                                        <span class="admin-course-department">
                                            Computer Science Faculty
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <span class="department-badge">
                                        <?= htmlspecialchars(
                                            $instructor['department_name']
                                        ) ?>
                                    </span>

                                </td>

                                <td>

                                    <?php if (!empty($instructor['email'])): ?>

                                        <span class="contact-value">
                                            <?= htmlspecialchars(
                                                $instructor['email']
                                            ) ?>
                                        </span>

                                    <?php else: ?>

                                        <span class="empty-value">
                                            Not provided
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <?php if (!empty($instructor['phone'])): ?>

                                        <span class="contact-value">
                                            <?= htmlspecialchars(
                                                $instructor['phone']
                                            ) ?>
                                        </span>

                                    <?php else: ?>

                                        <span class="empty-value">
                                            Not provided
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <div class="capacity-cell">

                                        <strong>
                                            <?= (int) $instructor['total_courses'] ?>
                                        </strong>

                                        <span>
                                            courses
                                        </span>

                                    </div>

                                </td>

                                <td>

                                    <div class="admin-course-actions">

                                        <a
                                            href="instructor-edit.php?id=<?= (int) $instructor['id'] ?>"
                                            class="admin-edit-button"
                                        >
                                            Edit
                                        </a>

                                        <form
                                            method="POST"
                                            action="instructor-delete.php"
                                            class="admin-delete-form"
                                            onsubmit="return confirm('Are you sure you want to delete this instructor?');"
                                        >

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?= (int) $instructor['id'] ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?= htmlspecialchars($csrfToken) ?>"
                                            >

                                            <button
                                                type="submit"
                                                class="admin-delete-button"
                                            >
                                                Delete
                                            </button>

                                        </form>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <div
                id="noInstructorResults"
                class="admin-search-empty"
                style="display: none;"
            >

                <div class="admin-search-empty-icon">
                    ⌕
                </div>

                <h3>
                    No matching instructors
                </h3>

                <p>
                    Try searching with another name, department, email, or phone number.
                </p>

            </div>

        </section>

    </main>

</div>

<script>

const searchInput = document.getElementById("instructorSearch");
const table = document.getElementById("instructorsTable");
const noResults = document.getElementById("noInstructorResults");

if (searchInput && table) {

    const rows = table.querySelectorAll(
        "tbody .admin-course-row"
    );

    searchInput.addEventListener(
        "input",
        function () {

            const searchValue = searchInput.value
                .toLowerCase()
                .trim();

            let visibleRows = 0;

            rows.forEach(function (row) {

                const rowText =
                    row.innerText.toLowerCase();

                const matches =
                    rowText.includes(searchValue);

                row.style.display =
                    matches ? "" : "none";

                if (matches) {
                    visibleRows++;
                }

            });

            if (noResults) {

                noResults.style.display =
                    visibleRows === 0 && searchValue !== ""
                        ? "block"
                        : "none";
            }

        }
    );
}

</script>

</body>

</html>