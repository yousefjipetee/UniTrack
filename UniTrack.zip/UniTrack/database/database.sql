-- ============================================================
-- UniTrack - University Course Management System
-- Database: unitrack
-- ============================================================

CREATE DATABASE IF NOT EXISTS unitrack
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE unitrack;

-- ============================================================
-- 1. USERS
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(255) NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'student') NOT NULL DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 2. DEPARTMENTS
-- ============================================================

CREATE TABLE IF NOT EXISTS departments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 3. INSTRUCTORS
-- ============================================================

CREATE TABLE IF NOT EXISTS instructors (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department_id INT UNSIGNED NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NULL,
    phone VARCHAR(30) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_instructor_department
        FOREIGN KEY (department_id)
        REFERENCES departments(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 4. COURSES
-- ============================================================

CREATE TABLE IF NOT EXISTS courses (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    department_id INT UNSIGNED NOT NULL,
    instructor_id INT UNSIGNED NOT NULL,
    course_code VARCHAR(20) NOT NULL UNIQUE,
    course_name VARCHAR(150) NOT NULL,
    description TEXT,
    credits TINYINT UNSIGNED NOT NULL,
    capacity INT UNSIGNED NOT NULL,
    schedule VARCHAR(100) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_course_department
        FOREIGN KEY (department_id)
        REFERENCES departments(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_course_instructor
        FOREIGN KEY (instructor_id)
        REFERENCES instructors(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 5. ENROLLMENTS
-- ============================================================

CREATE TABLE IF NOT EXISTS enrollments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    course_id INT UNSIGNED NOT NULL,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('active', 'dropped', 'completed') NOT NULL DEFAULT 'active',

    CONSTRAINT fk_enrollment_student
        FOREIGN KEY (student_id)
        REFERENCES users(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT fk_enrollment_course
        FOREIGN KEY (course_id)
        REFERENCES courses(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    UNIQUE KEY unique_student_course (student_id, course_id)
) ENGINE=InnoDB
DEFAULT CHARSET=utf8mb4
COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- 6. DEPARTMENT DATA
-- ============================================================

INSERT INTO departments (name, description)
VALUES
(
    'Computer Science',
    'Department of Computer Science'
);


-- ============================================================
-- 7. INSTRUCTORS
-- ============================================================

INSERT INTO instructors
    (department_id, name, email, phone)
VALUES
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'محمد العيسى',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'معن الزعبي',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'سامي قواسمة',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'معن الرشدان',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'معتز عبد الواحد',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'أريج الحمود',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'حسن السخني',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'أحمد العمري',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'أحمد الشياب',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'محمد العمر',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'سليمان بني بكر',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'نشأت الرفاعي',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'إقبال الزيتون',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'ندى الجراح',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'سوسن الشرعة',
    NULL,
    NULL
),
(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    'يزن الوقفي',
    NULL,
    NULL
);


-- ============================================================
-- 8. COURSES
-- ============================================================

INSERT INTO courses
(
    department_id,
    instructor_id,
    course_code,
    course_name,
    description,
    credits,
    capacity,
    schedule
)
VALUES

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'محمد العيسى' LIMIT 1),
    'CS101',
    'برمجة 1',
    'Introduction to programming concepts and problem solving.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'معن الزعبي' LIMIT 1),
    'CS102',
    'برمجة 2',
    'Advanced programming concepts and structured problem solving.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'سامي قواسمة' LIMIT 1),
    'CS201',
    'تراكيب بيانات',
    'Fundamental data structures and their applications.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'معن الرشدان' LIMIT 1),
    'CS202',
    'تصميم منطق رقمي',
    'Introduction to digital logic and digital system design.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'معتز عبد الواحد' LIMIT 1),
    'CS203',
    'تنظيم ومعمارية الحاسوب',
    'Fundamentals of computer organization and architecture.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'أريج الحمود' LIMIT 1),
    'CS301',
    'نظم التشغيل',
    'Operating system concepts, processes, memory, and file systems.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'حسن السخني' LIMIT 1),
    'CS302',
    'الحوسبة السحابية',
    'Fundamentals of cloud computing and cloud-based services.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'أحمد العمري' LIMIT 1),
    'CS303',
    'النظم الموزعة',
    'Concepts and principles of distributed computing systems.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'أحمد الشياب' LIMIT 1),
    'CS304',
    'بروتوكولات الشبكات الحاسوبية',
    'Networking concepts and common computer network protocols.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'محمد العمر' LIMIT 1),
    'CS305',
    'الشبكات وتراسل البيانات',
    'Data communication and computer networking fundamentals.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'سليمان بني بكر' LIMIT 1),
    'CS204',
    'برمجة كينونية',
    'Object-oriented programming concepts and implementation.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'نشأت الرفاعي' LIMIT 1),
    'CS205',
    'أساسيات قواعد البيانات',
    'Database concepts, relational models, and SQL fundamentals.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'إقبال الزيتون' LIMIT 1),
    'CS306',
    'تطبيقات قواعد البيانات',
    'Practical database design and database application development.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'ندى الجراح' LIMIT 1),
    'CS206',
    'البرمجة المرئية',
    'Introduction to visual programming and graphical applications.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'سوسن الشرعة' LIMIT 1),
    'CS307',
    'تطوير تطبيقات الويب',
    'Web development concepts and full-stack application development.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'يزن الوقفي' LIMIT 1),
    'CS308',
    'برمجة التطبيقات الخلوية',
    'Fundamentals of mobile application development.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'محمد العيسى' LIMIT 1),
    'CS309',
    'علم البيانات',
    'Introduction to data analysis and data science concepts.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'معن الزعبي' LIMIT 1),
    'CS207',
    'الوسائط المتعددة',
    'Fundamentals of multimedia technologies and applications.',
    3,
    30,
    NULL
),

(
    (SELECT id FROM departments WHERE name = 'Computer Science'),
    (SELECT id FROM instructors WHERE name = 'سامي قواسمة' LIMIT 1),
    'CS310',
    'تحليل الخوارزميات وتصميمها',
    'Algorithm analysis, complexity, and algorithm design techniques.',
    3,
    30,
    NULL
);