<?php

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../classes/Course.php';
require_once __DIR__ . '/../classes/Enrollment.php';

requireStudent();

header('Content-Type: application/json; charset=utf-8');

function sendResponse(
    bool $success,
    string $message,
    int $statusCode = 200,
    array $data = []
): never {

    http_response_code($statusCode);

    echo json_encode(
        array_merge(
            [
                'success' => $success,
                'message' => $message
            ],
            $data
        ),
        JSON_UNESCAPED_UNICODE
    );

    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse(
        false,
        'Invalid request method.',
        405
    );
}

$input = json_decode(
    file_get_contents('php://input'),
    true
);

if (!is_array($input)) {
    sendResponse(
        false,
        'Invalid request data.',
        400
    );
}

if (!verifyCsrfToken($input['csrf_token'] ?? null)) {
    sendResponse(
        false,
        'Invalid security token.',
        403
    );
}

$courseId = filter_var(
    $input['course_id'] ?? null,
    FILTER_VALIDATE_INT
);

if (!$courseId || $courseId <= 0) {
    sendResponse(
        false,
        'Invalid course ID.',
        400
    );
}

$studentId = (int) $_SESSION['user_id'];

$course = new Course();
$enrollment = new Enrollment();

try {

    $courseData = $course->getById($courseId);

    if ($courseData === null) {
        sendResponse(
            false,
            'Course not found.',
            404
        );
    }

    $existingEnrollment = $enrollment->get(
        $studentId,
        $courseId
    );

    if (
        $existingEnrollment === null ||
        $existingEnrollment['status'] !== 'active'
    ) {
        sendResponse(
            false,
            'You are not actively enrolled in this course.',
            409
        );
    }

    if (!$enrollment->drop($studentId, $courseId)) {
        sendResponse(
            false,
            'Failed to drop the course.',
            500
        );
    }

    $enrolledCount = $course->getActiveEnrollmentCount(
        $courseId
    );

    $remainingSeats = max(
        0,
        (int) $courseData['capacity'] - $enrolledCount
    );

    sendResponse(
        true,
        'Course dropped successfully.',
        200,
        [
            'enrolled_count' => $enrolledCount,
            'remaining_seats' => $remainingSeats
        ]
    );

} catch (Throwable $e) {

    sendResponse(
        false,
        'An unexpected error occurred.',
        500
    );
}