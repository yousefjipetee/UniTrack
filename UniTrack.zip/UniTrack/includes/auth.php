<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

function requireLogin(): void
{
    if (!isLoggedIn()) {
        header("Location: /UniTrack/login.php");
        exit;
    }
}

function isAdmin(): bool
{
    return isset($_SESSION['user_role'])
        && $_SESSION['user_role'] === 'admin';
}

function isStudent(): bool
{
    return isset($_SESSION['user_role'])
        && $_SESSION['user_role'] === 'student';
}

function requireAdmin(): void
{
    requireLogin();

    if (!isAdmin()) {
        http_response_code(403);
        exit("Access denied.");
    }
}

function requireStudent(): void
{
    requireLogin();

    if (!isStudent()) {
        http_response_code(403);
        exit("Access denied.");
    }
}