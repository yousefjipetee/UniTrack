<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'unitrack');

define('BASE_URL', '/UniTrack/');

define(
    'ENCRYPTION_KEY',
    '7f3c9a2e5d8b1f604c7a9e2d5f8b3c1a6e9d2f5a8b1c4e7f0a3d6c9b2e5f8a1'
);